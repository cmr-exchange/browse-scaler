require("./main.js");

goog.require("browse-scaler-cljc.handler");

exports.main = lambda.core.handle-event;
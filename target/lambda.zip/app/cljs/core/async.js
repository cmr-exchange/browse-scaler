// Compiled by ClojureScript 1.10.238 {:target :nodejs}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var G__3733 = arguments.length;
switch (G__3733) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.call(null,f,true);
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if(typeof cljs.core.async.t_cljs$core$async3734 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async3734 = (function (f,blockable,meta3735){
this.f = f;
this.blockable = blockable;
this.meta3735 = meta3735;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async3734.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_3736,meta3735__$1){
var self__ = this;
var _3736__$1 = this;
return (new cljs.core.async.t_cljs$core$async3734(self__.f,self__.blockable,meta3735__$1));
});

cljs.core.async.t_cljs$core$async3734.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_3736){
var self__ = this;
var _3736__$1 = this;
return self__.meta3735;
});

cljs.core.async.t_cljs$core$async3734.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async3734.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async3734.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
});

cljs.core.async.t_cljs$core$async3734.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
});

cljs.core.async.t_cljs$core$async3734.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"blockable","blockable",-28395259,null),new cljs.core.Symbol(null,"meta3735","meta3735",-287559816,null)], null);
});

cljs.core.async.t_cljs$core$async3734.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async3734.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async3734";

cljs.core.async.t_cljs$core$async3734.cljs$lang$ctorPrWriter = (function (this__4161__auto__,writer__4162__auto__,opt__4163__auto__){
return cljs.core._write.call(null,writer__4162__auto__,"cljs.core.async/t_cljs$core$async3734");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async3734.
 */
cljs.core.async.__GT_t_cljs$core$async3734 = (function cljs$core$async$__GT_t_cljs$core$async3734(f__$1,blockable__$1,meta3735){
return (new cljs.core.async.t_cljs$core$async3734(f__$1,blockable__$1,meta3735));
});

}

return (new cljs.core.async.t_cljs$core$async3734(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
});

cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2;

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer.call(null,n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer.call(null,n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer.call(null,n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if(!((buff == null))){
if(((false) || ((cljs.core.PROTOCOL_SENTINEL === buff.cljs$core$async$impl$protocols$UnblockingBuffer$)))){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_.call(null,cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_.call(null,cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var G__3740 = arguments.length;
switch (G__3740) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.call(null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.call(null,buf_or_n,null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.call(null,buf_or_n,xform,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.call(null,buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
if(cljs.core.truth_(buf_or_n__$1)){
} else {
throw (new Error(["Assert failed: ","buffer must be supplied when transducer is","\n","buf-or-n"].join('')));
}
} else {
}

return cljs.core.async.impl.channels.chan.call(null,((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer.call(null,buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
});

cljs.core.async.chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var G__3743 = arguments.length;
switch (G__3743) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.call(null,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.call(null,xform,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.call(null,cljs.core.async.impl.buffers.promise_buffer.call(null),xform,ex_handler);
});

cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout.call(null,msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var G__3746 = arguments.length;
switch (G__3746) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.call(null,port,fn1,true);
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.fn_handler.call(null,fn1));
if(cljs.core.truth_(ret)){
var val_3748 = cljs.core.deref.call(null,ret);
if(cljs.core.truth_(on_caller_QMARK_)){
fn1.call(null,val_3748);
} else {
cljs.core.async.impl.dispatch.run.call(null,((function (val_3748,ret){
return (function (){
return fn1.call(null,val_3748);
});})(val_3748,ret))
);
}
} else {
}

return null;
});

cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3;

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.call(null,cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn0 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn0 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var G__3750 = arguments.length;
switch (G__3750) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__5455__auto__ = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__5455__auto__)){
var ret = temp__5455__auto__;
return cljs.core.deref.call(null,ret);
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.call(null,port,val,fn1,true);
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__5455__auto__ = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fn_handler.call(null,fn1));
if(cljs.core.truth_(temp__5455__auto__)){
var retb = temp__5455__auto__;
var ret = cljs.core.deref.call(null,retb);
if(cljs.core.truth_(on_caller_QMARK_)){
fn1.call(null,ret);
} else {
cljs.core.async.impl.dispatch.run.call(null,((function (ret,retb,temp__5455__auto__){
return (function (){
return fn1.call(null,ret);
});})(ret,retb,temp__5455__auto__))
);
}

return ret;
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4;

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_.call(null,port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__4376__auto___3752 = n;
var x_3753 = (0);
while(true){
if((x_3753 < n__4376__auto___3752)){
(a[x_3753] = (0));

var G__3754 = (x_3753 + (1));
x_3753 = G__3754;
continue;
} else {
}
break;
}

var i = (1);
while(true){
if(cljs.core._EQ_.call(null,i,n)){
return a;
} else {
var j = cljs.core.rand_int.call(null,i);
(a[i] = (a[j]));

(a[j] = i);

var G__3755 = (i + (1));
i = G__3755;
continue;
}
break;
}
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = cljs.core.atom.call(null,true);
if(typeof cljs.core.async.t_cljs$core$async3756 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async3756 = (function (flag,meta3757){
this.flag = flag;
this.meta3757 = meta3757;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async3756.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (flag){
return (function (_3758,meta3757__$1){
var self__ = this;
var _3758__$1 = this;
return (new cljs.core.async.t_cljs$core$async3756(self__.flag,meta3757__$1));
});})(flag))
;

cljs.core.async.t_cljs$core$async3756.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (flag){
return (function (_3758){
var self__ = this;
var _3758__$1 = this;
return self__.meta3757;
});})(flag))
;

cljs.core.async.t_cljs$core$async3756.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async3756.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.deref.call(null,self__.flag);
});})(flag))
;

cljs.core.async.t_cljs$core$async3756.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async3756.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.flag,null);

return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async3756.getBasis = ((function (flag){
return (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"meta3757","meta3757",-846569127,null)], null);
});})(flag))
;

cljs.core.async.t_cljs$core$async3756.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async3756.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async3756";

cljs.core.async.t_cljs$core$async3756.cljs$lang$ctorPrWriter = ((function (flag){
return (function (this__4161__auto__,writer__4162__auto__,opt__4163__auto__){
return cljs.core._write.call(null,writer__4162__auto__,"cljs.core.async/t_cljs$core$async3756");
});})(flag))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async3756.
 */
cljs.core.async.__GT_t_cljs$core$async3756 = ((function (flag){
return (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async3756(flag__$1,meta3757){
return (new cljs.core.async.t_cljs$core$async3756(flag__$1,meta3757));
});})(flag))
;

}

return (new cljs.core.async.t_cljs$core$async3756(flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if(typeof cljs.core.async.t_cljs$core$async3759 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async3759 = (function (flag,cb,meta3760){
this.flag = flag;
this.cb = cb;
this.meta3760 = meta3760;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async3759.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_3761,meta3760__$1){
var self__ = this;
var _3761__$1 = this;
return (new cljs.core.async.t_cljs$core$async3759(self__.flag,self__.cb,meta3760__$1));
});

cljs.core.async.t_cljs$core$async3759.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_3761){
var self__ = this;
var _3761__$1 = this;
return self__.meta3760;
});

cljs.core.async.t_cljs$core$async3759.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async3759.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_.call(null,self__.flag);
});

cljs.core.async.t_cljs$core$async3759.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async3759.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit.call(null,self__.flag);

return self__.cb;
});

cljs.core.async.t_cljs$core$async3759.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"cb","cb",-2064487928,null),new cljs.core.Symbol(null,"meta3760","meta3760",-60128036,null)], null);
});

cljs.core.async.t_cljs$core$async3759.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async3759.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async3759";

cljs.core.async.t_cljs$core$async3759.cljs$lang$ctorPrWriter = (function (this__4161__auto__,writer__4162__auto__,opt__4163__auto__){
return cljs.core._write.call(null,writer__4162__auto__,"cljs.core.async/t_cljs$core$async3759");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async3759.
 */
cljs.core.async.__GT_t_cljs$core$async3759 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async3759(flag__$1,cb__$1,meta3760){
return (new cljs.core.async.t_cljs$core$async3759(flag__$1,cb__$1,meta3760));
});

}

return (new cljs.core.async.t_cljs$core$async3759(flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){
var flag = cljs.core.async.alt_flag.call(null);
var n = cljs.core.count.call(null,ports);
var idxs = cljs.core.async.random_array.call(null,n);
var priority = new cljs.core.Keyword(null,"priority","priority",1431093715).cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.call(null,ports,idx);
var wport = ((cljs.core.vector_QMARK_.call(null,port))?port.call(null,(0)):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = port.call(null,(1));
return cljs.core.async.impl.protocols.put_BANG_.call(null,wport,val,cljs.core.async.alt_handler.call(null,flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__3762_SHARP_){
return fret.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__3762_SHARP_,wport], null));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.alt_handler.call(null,flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__3763_SHARP_){
return fret.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__3763_SHARP_,port], null));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.deref.call(null,vbox),(function (){var or__3922__auto__ = wport;
if(cljs.core.truth_(or__3922__auto__)){
return or__3922__auto__;
} else {
return port;
}
})()], null));
} else {
var G__3764 = (i + (1));
i = G__3764;
continue;
}
} else {
return null;
}
break;
}
})();
var or__3922__auto__ = ret;
if(cljs.core.truth_(or__3922__auto__)){
return or__3922__auto__;
} else {
if(cljs.core.contains_QMARK_.call(null,opts,new cljs.core.Keyword(null,"default","default",-1987822328))){
var temp__5457__auto__ = (function (){var and__3911__auto__ = cljs.core.async.impl.protocols.active_QMARK_.call(null,flag);
if(cljs.core.truth_(and__3911__auto__)){
return cljs.core.async.impl.protocols.commit.call(null,flag);
} else {
return and__3911__auto__;
}
})();
if(cljs.core.truth_(temp__5457__auto__)){
var got = temp__5457__auto__;
return cljs.core.async.impl.channels.box.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"default","default",-1987822328).cljs$core$IFn$_invoke$arity$1(opts),new cljs.core.Keyword(null,"default","default",-1987822328)], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__4502__auto__ = [];
var len__4499__auto___3770 = arguments.length;
var i__4500__auto___3771 = (0);
while(true){
if((i__4500__auto___3771 < len__4499__auto___3770)){
args__4502__auto__.push((arguments[i__4500__auto___3771]));

var G__3772 = (i__4500__auto___3771 + (1));
i__4500__auto___3771 = G__3772;
continue;
} else {
}
break;
}

var argseq__4503__auto__ = ((((1) < args__4502__auto__.length))?(new cljs.core.IndexedSeq(args__4502__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4503__auto__);
});

cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__3767){
var map__3768 = p__3767;
var map__3768__$1 = ((((!((map__3768 == null)))?(((((map__3768.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__3768.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__3768):map__3768);
var opts = map__3768__$1;
throw (new Error("alts! used not in (go ...) block"));
});

cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq3765){
var G__3766 = cljs.core.first.call(null,seq3765);
var seq3765__$1 = cljs.core.next.call(null,seq3765);
var self__4486__auto__ = this;
return self__4486__auto__.cljs$core$IFn$_invoke$arity$variadic(G__3766,seq3765__$1);
});

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fn_handler.call(null,cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref.call(null,ret);
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.fn_handler.call(null,cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref.call(null,ret);
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var G__3774 = arguments.length;
switch (G__3774) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.call(null,from,to,true);
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__3673__auto___3820 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___3820){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___3820){
return (function (state_3798){
var state_val_3799 = (state_3798[(1)]);
if((state_val_3799 === (7))){
var inst_3794 = (state_3798[(2)]);
var state_3798__$1 = state_3798;
var statearr_3800_3821 = state_3798__$1;
(statearr_3800_3821[(2)] = inst_3794);

(statearr_3800_3821[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3799 === (1))){
var state_3798__$1 = state_3798;
var statearr_3801_3822 = state_3798__$1;
(statearr_3801_3822[(2)] = null);

(statearr_3801_3822[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3799 === (4))){
var inst_3777 = (state_3798[(7)]);
var inst_3777__$1 = (state_3798[(2)]);
var inst_3778 = (inst_3777__$1 == null);
var state_3798__$1 = (function (){var statearr_3802 = state_3798;
(statearr_3802[(7)] = inst_3777__$1);

return statearr_3802;
})();
if(cljs.core.truth_(inst_3778)){
var statearr_3803_3823 = state_3798__$1;
(statearr_3803_3823[(1)] = (5));

} else {
var statearr_3804_3824 = state_3798__$1;
(statearr_3804_3824[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3799 === (13))){
var state_3798__$1 = state_3798;
var statearr_3805_3825 = state_3798__$1;
(statearr_3805_3825[(2)] = null);

(statearr_3805_3825[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3799 === (6))){
var inst_3777 = (state_3798[(7)]);
var state_3798__$1 = state_3798;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_3798__$1,(11),to,inst_3777);
} else {
if((state_val_3799 === (3))){
var inst_3796 = (state_3798[(2)]);
var state_3798__$1 = state_3798;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_3798__$1,inst_3796);
} else {
if((state_val_3799 === (12))){
var state_3798__$1 = state_3798;
var statearr_3806_3826 = state_3798__$1;
(statearr_3806_3826[(2)] = null);

(statearr_3806_3826[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3799 === (2))){
var state_3798__$1 = state_3798;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_3798__$1,(4),from);
} else {
if((state_val_3799 === (11))){
var inst_3787 = (state_3798[(2)]);
var state_3798__$1 = state_3798;
if(cljs.core.truth_(inst_3787)){
var statearr_3807_3827 = state_3798__$1;
(statearr_3807_3827[(1)] = (12));

} else {
var statearr_3808_3828 = state_3798__$1;
(statearr_3808_3828[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3799 === (9))){
var state_3798__$1 = state_3798;
var statearr_3809_3829 = state_3798__$1;
(statearr_3809_3829[(2)] = null);

(statearr_3809_3829[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3799 === (5))){
var state_3798__$1 = state_3798;
if(cljs.core.truth_(close_QMARK_)){
var statearr_3810_3830 = state_3798__$1;
(statearr_3810_3830[(1)] = (8));

} else {
var statearr_3811_3831 = state_3798__$1;
(statearr_3811_3831[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3799 === (14))){
var inst_3792 = (state_3798[(2)]);
var state_3798__$1 = state_3798;
var statearr_3812_3832 = state_3798__$1;
(statearr_3812_3832[(2)] = inst_3792);

(statearr_3812_3832[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3799 === (10))){
var inst_3784 = (state_3798[(2)]);
var state_3798__$1 = state_3798;
var statearr_3813_3833 = state_3798__$1;
(statearr_3813_3833[(2)] = inst_3784);

(statearr_3813_3833[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3799 === (8))){
var inst_3781 = cljs.core.async.close_BANG_.call(null,to);
var state_3798__$1 = state_3798;
var statearr_3814_3834 = state_3798__$1;
(statearr_3814_3834[(2)] = inst_3781);

(statearr_3814_3834[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___3820))
;
return ((function (switch__3583__auto__,c__3673__auto___3820){
return (function() {
var cljs$core$async$state_machine__3584__auto__ = null;
var cljs$core$async$state_machine__3584__auto____0 = (function (){
var statearr_3815 = [null,null,null,null,null,null,null,null];
(statearr_3815[(0)] = cljs$core$async$state_machine__3584__auto__);

(statearr_3815[(1)] = (1));

return statearr_3815;
});
var cljs$core$async$state_machine__3584__auto____1 = (function (state_3798){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_3798);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e3816){if((e3816 instanceof Object)){
var ex__3587__auto__ = e3816;
var statearr_3817_3835 = state_3798;
(statearr_3817_3835[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_3798);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e3816;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__3836 = state_3798;
state_3798 = G__3836;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$state_machine__3584__auto__ = function(state_3798){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__3584__auto____1.call(this,state_3798);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__3584__auto____0;
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__3584__auto____1;
return cljs$core$async$state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___3820))
})();
var state__3675__auto__ = (function (){var statearr_3818 = f__3674__auto__.call(null);
(statearr_3818[(6)] = c__3673__auto___3820);

return statearr_3818;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___3820))
);


return to;
});

cljs.core.async.pipe.cljs$lang$maxFixedArity = 3;

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){
if((n > (0))){
} else {
throw (new Error("Assert failed: (pos? n)"));
}

var jobs = cljs.core.async.chan.call(null,n);
var results = cljs.core.async.chan.call(null,n);
var process = ((function (jobs,results){
return (function (p__3837){
var vec__3838 = p__3837;
var v = cljs.core.nth.call(null,vec__3838,(0),null);
var p = cljs.core.nth.call(null,vec__3838,(1),null);
var job = vec__3838;
if((job == null)){
cljs.core.async.close_BANG_.call(null,results);

return null;
} else {
var res = cljs.core.async.chan.call(null,(1),xf,ex_handler);
var c__3673__auto___4009 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___4009,res,vec__3838,v,p,job,jobs,results){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___4009,res,vec__3838,v,p,job,jobs,results){
return (function (state_3845){
var state_val_3846 = (state_3845[(1)]);
if((state_val_3846 === (1))){
var state_3845__$1 = state_3845;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_3845__$1,(2),res,v);
} else {
if((state_val_3846 === (2))){
var inst_3842 = (state_3845[(2)]);
var inst_3843 = cljs.core.async.close_BANG_.call(null,res);
var state_3845__$1 = (function (){var statearr_3847 = state_3845;
(statearr_3847[(7)] = inst_3842);

return statearr_3847;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_3845__$1,inst_3843);
} else {
return null;
}
}
});})(c__3673__auto___4009,res,vec__3838,v,p,job,jobs,results))
;
return ((function (switch__3583__auto__,c__3673__auto___4009,res,vec__3838,v,p,job,jobs,results){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0 = (function (){
var statearr_3848 = [null,null,null,null,null,null,null,null];
(statearr_3848[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__);

(statearr_3848[(1)] = (1));

return statearr_3848;
});
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1 = (function (state_3845){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_3845);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e3849){if((e3849 instanceof Object)){
var ex__3587__auto__ = e3849;
var statearr_3850_4010 = state_3845;
(statearr_3850_4010[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_3845);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e3849;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4011 = state_3845;
state_3845 = G__4011;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__ = function(state_3845){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1.call(this,state_3845);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___4009,res,vec__3838,v,p,job,jobs,results))
})();
var state__3675__auto__ = (function (){var statearr_3851 = f__3674__auto__.call(null);
(statearr_3851[(6)] = c__3673__auto___4009);

return statearr_3851;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___4009,res,vec__3838,v,p,job,jobs,results))
);


cljs.core.async.put_BANG_.call(null,p,res);

return true;
}
});})(jobs,results))
;
var async = ((function (jobs,results,process){
return (function (p__3852){
var vec__3853 = p__3852;
var v = cljs.core.nth.call(null,vec__3853,(0),null);
var p = cljs.core.nth.call(null,vec__3853,(1),null);
var job = vec__3853;
if((job == null)){
cljs.core.async.close_BANG_.call(null,results);

return null;
} else {
var res = cljs.core.async.chan.call(null,(1));
xf.call(null,v,res);

cljs.core.async.put_BANG_.call(null,p,res);

return true;
}
});})(jobs,results,process))
;
var n__4376__auto___4012 = n;
var __4013 = (0);
while(true){
if((__4013 < n__4376__auto___4012)){
var G__3856_4014 = type;
var G__3856_4015__$1 = (((G__3856_4014 instanceof cljs.core.Keyword))?G__3856_4014.fqn:null);
switch (G__3856_4015__$1) {
case "compute":
var c__3673__auto___4017 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (__4013,c__3673__auto___4017,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (__4013,c__3673__auto___4017,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async){
return (function (state_3869){
var state_val_3870 = (state_3869[(1)]);
if((state_val_3870 === (1))){
var state_3869__$1 = state_3869;
var statearr_3871_4018 = state_3869__$1;
(statearr_3871_4018[(2)] = null);

(statearr_3871_4018[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3870 === (2))){
var state_3869__$1 = state_3869;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_3869__$1,(4),jobs);
} else {
if((state_val_3870 === (3))){
var inst_3867 = (state_3869[(2)]);
var state_3869__$1 = state_3869;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_3869__$1,inst_3867);
} else {
if((state_val_3870 === (4))){
var inst_3859 = (state_3869[(2)]);
var inst_3860 = process.call(null,inst_3859);
var state_3869__$1 = state_3869;
if(cljs.core.truth_(inst_3860)){
var statearr_3872_4019 = state_3869__$1;
(statearr_3872_4019[(1)] = (5));

} else {
var statearr_3873_4020 = state_3869__$1;
(statearr_3873_4020[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3870 === (5))){
var state_3869__$1 = state_3869;
var statearr_3874_4021 = state_3869__$1;
(statearr_3874_4021[(2)] = null);

(statearr_3874_4021[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3870 === (6))){
var state_3869__$1 = state_3869;
var statearr_3875_4022 = state_3869__$1;
(statearr_3875_4022[(2)] = null);

(statearr_3875_4022[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3870 === (7))){
var inst_3865 = (state_3869[(2)]);
var state_3869__$1 = state_3869;
var statearr_3876_4023 = state_3869__$1;
(statearr_3876_4023[(2)] = inst_3865);

(statearr_3876_4023[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(__4013,c__3673__auto___4017,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async))
;
return ((function (__4013,switch__3583__auto__,c__3673__auto___4017,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0 = (function (){
var statearr_3877 = [null,null,null,null,null,null,null];
(statearr_3877[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__);

(statearr_3877[(1)] = (1));

return statearr_3877;
});
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1 = (function (state_3869){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_3869);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e3878){if((e3878 instanceof Object)){
var ex__3587__auto__ = e3878;
var statearr_3879_4024 = state_3869;
(statearr_3879_4024[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_3869);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e3878;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4025 = state_3869;
state_3869 = G__4025;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__ = function(state_3869){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1.call(this,state_3869);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__;
})()
;})(__4013,switch__3583__auto__,c__3673__auto___4017,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async))
})();
var state__3675__auto__ = (function (){var statearr_3880 = f__3674__auto__.call(null);
(statearr_3880[(6)] = c__3673__auto___4017);

return statearr_3880;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(__4013,c__3673__auto___4017,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async))
);


break;
case "async":
var c__3673__auto___4026 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (__4013,c__3673__auto___4026,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (__4013,c__3673__auto___4026,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async){
return (function (state_3893){
var state_val_3894 = (state_3893[(1)]);
if((state_val_3894 === (1))){
var state_3893__$1 = state_3893;
var statearr_3895_4027 = state_3893__$1;
(statearr_3895_4027[(2)] = null);

(statearr_3895_4027[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3894 === (2))){
var state_3893__$1 = state_3893;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_3893__$1,(4),jobs);
} else {
if((state_val_3894 === (3))){
var inst_3891 = (state_3893[(2)]);
var state_3893__$1 = state_3893;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_3893__$1,inst_3891);
} else {
if((state_val_3894 === (4))){
var inst_3883 = (state_3893[(2)]);
var inst_3884 = async.call(null,inst_3883);
var state_3893__$1 = state_3893;
if(cljs.core.truth_(inst_3884)){
var statearr_3896_4028 = state_3893__$1;
(statearr_3896_4028[(1)] = (5));

} else {
var statearr_3897_4029 = state_3893__$1;
(statearr_3897_4029[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3894 === (5))){
var state_3893__$1 = state_3893;
var statearr_3898_4030 = state_3893__$1;
(statearr_3898_4030[(2)] = null);

(statearr_3898_4030[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3894 === (6))){
var state_3893__$1 = state_3893;
var statearr_3899_4031 = state_3893__$1;
(statearr_3899_4031[(2)] = null);

(statearr_3899_4031[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3894 === (7))){
var inst_3889 = (state_3893[(2)]);
var state_3893__$1 = state_3893;
var statearr_3900_4032 = state_3893__$1;
(statearr_3900_4032[(2)] = inst_3889);

(statearr_3900_4032[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(__4013,c__3673__auto___4026,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async))
;
return ((function (__4013,switch__3583__auto__,c__3673__auto___4026,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0 = (function (){
var statearr_3901 = [null,null,null,null,null,null,null];
(statearr_3901[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__);

(statearr_3901[(1)] = (1));

return statearr_3901;
});
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1 = (function (state_3893){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_3893);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e3902){if((e3902 instanceof Object)){
var ex__3587__auto__ = e3902;
var statearr_3903_4033 = state_3893;
(statearr_3903_4033[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_3893);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e3902;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4034 = state_3893;
state_3893 = G__4034;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__ = function(state_3893){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1.call(this,state_3893);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__;
})()
;})(__4013,switch__3583__auto__,c__3673__auto___4026,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async))
})();
var state__3675__auto__ = (function (){var statearr_3904 = f__3674__auto__.call(null);
(statearr_3904[(6)] = c__3673__auto___4026);

return statearr_3904;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(__4013,c__3673__auto___4026,G__3856_4014,G__3856_4015__$1,n__4376__auto___4012,jobs,results,process,async))
);


break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__3856_4015__$1)].join('')));

}

var G__4035 = (__4013 + (1));
__4013 = G__4035;
continue;
} else {
}
break;
}

var c__3673__auto___4036 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___4036,jobs,results,process,async){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___4036,jobs,results,process,async){
return (function (state_3926){
var state_val_3927 = (state_3926[(1)]);
if((state_val_3927 === (1))){
var state_3926__$1 = state_3926;
var statearr_3928_4037 = state_3926__$1;
(statearr_3928_4037[(2)] = null);

(statearr_3928_4037[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3927 === (2))){
var state_3926__$1 = state_3926;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_3926__$1,(4),from);
} else {
if((state_val_3927 === (3))){
var inst_3924 = (state_3926[(2)]);
var state_3926__$1 = state_3926;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_3926__$1,inst_3924);
} else {
if((state_val_3927 === (4))){
var inst_3907 = (state_3926[(7)]);
var inst_3907__$1 = (state_3926[(2)]);
var inst_3908 = (inst_3907__$1 == null);
var state_3926__$1 = (function (){var statearr_3929 = state_3926;
(statearr_3929[(7)] = inst_3907__$1);

return statearr_3929;
})();
if(cljs.core.truth_(inst_3908)){
var statearr_3930_4038 = state_3926__$1;
(statearr_3930_4038[(1)] = (5));

} else {
var statearr_3931_4039 = state_3926__$1;
(statearr_3931_4039[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3927 === (5))){
var inst_3910 = cljs.core.async.close_BANG_.call(null,jobs);
var state_3926__$1 = state_3926;
var statearr_3932_4040 = state_3926__$1;
(statearr_3932_4040[(2)] = inst_3910);

(statearr_3932_4040[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3927 === (6))){
var inst_3912 = (state_3926[(8)]);
var inst_3907 = (state_3926[(7)]);
var inst_3912__$1 = cljs.core.async.chan.call(null,(1));
var inst_3913 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_3914 = [inst_3907,inst_3912__$1];
var inst_3915 = (new cljs.core.PersistentVector(null,2,(5),inst_3913,inst_3914,null));
var state_3926__$1 = (function (){var statearr_3933 = state_3926;
(statearr_3933[(8)] = inst_3912__$1);

return statearr_3933;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_3926__$1,(8),jobs,inst_3915);
} else {
if((state_val_3927 === (7))){
var inst_3922 = (state_3926[(2)]);
var state_3926__$1 = state_3926;
var statearr_3934_4041 = state_3926__$1;
(statearr_3934_4041[(2)] = inst_3922);

(statearr_3934_4041[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3927 === (8))){
var inst_3912 = (state_3926[(8)]);
var inst_3917 = (state_3926[(2)]);
var state_3926__$1 = (function (){var statearr_3935 = state_3926;
(statearr_3935[(9)] = inst_3917);

return statearr_3935;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_3926__$1,(9),results,inst_3912);
} else {
if((state_val_3927 === (9))){
var inst_3919 = (state_3926[(2)]);
var state_3926__$1 = (function (){var statearr_3936 = state_3926;
(statearr_3936[(10)] = inst_3919);

return statearr_3936;
})();
var statearr_3937_4042 = state_3926__$1;
(statearr_3937_4042[(2)] = null);

(statearr_3937_4042[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___4036,jobs,results,process,async))
;
return ((function (switch__3583__auto__,c__3673__auto___4036,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0 = (function (){
var statearr_3938 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_3938[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__);

(statearr_3938[(1)] = (1));

return statearr_3938;
});
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1 = (function (state_3926){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_3926);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e3939){if((e3939 instanceof Object)){
var ex__3587__auto__ = e3939;
var statearr_3940_4043 = state_3926;
(statearr_3940_4043[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_3926);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e3939;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4044 = state_3926;
state_3926 = G__4044;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__ = function(state_3926){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1.call(this,state_3926);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___4036,jobs,results,process,async))
})();
var state__3675__auto__ = (function (){var statearr_3941 = f__3674__auto__.call(null);
(statearr_3941[(6)] = c__3673__auto___4036);

return statearr_3941;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___4036,jobs,results,process,async))
);


var c__3673__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto__,jobs,results,process,async){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto__,jobs,results,process,async){
return (function (state_3979){
var state_val_3980 = (state_3979[(1)]);
if((state_val_3980 === (7))){
var inst_3975 = (state_3979[(2)]);
var state_3979__$1 = state_3979;
var statearr_3981_4045 = state_3979__$1;
(statearr_3981_4045[(2)] = inst_3975);

(statearr_3981_4045[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (20))){
var state_3979__$1 = state_3979;
var statearr_3982_4046 = state_3979__$1;
(statearr_3982_4046[(2)] = null);

(statearr_3982_4046[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (1))){
var state_3979__$1 = state_3979;
var statearr_3983_4047 = state_3979__$1;
(statearr_3983_4047[(2)] = null);

(statearr_3983_4047[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (4))){
var inst_3944 = (state_3979[(7)]);
var inst_3944__$1 = (state_3979[(2)]);
var inst_3945 = (inst_3944__$1 == null);
var state_3979__$1 = (function (){var statearr_3984 = state_3979;
(statearr_3984[(7)] = inst_3944__$1);

return statearr_3984;
})();
if(cljs.core.truth_(inst_3945)){
var statearr_3985_4048 = state_3979__$1;
(statearr_3985_4048[(1)] = (5));

} else {
var statearr_3986_4049 = state_3979__$1;
(statearr_3986_4049[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (15))){
var inst_3957 = (state_3979[(8)]);
var state_3979__$1 = state_3979;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_3979__$1,(18),to,inst_3957);
} else {
if((state_val_3980 === (21))){
var inst_3970 = (state_3979[(2)]);
var state_3979__$1 = state_3979;
var statearr_3987_4050 = state_3979__$1;
(statearr_3987_4050[(2)] = inst_3970);

(statearr_3987_4050[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (13))){
var inst_3972 = (state_3979[(2)]);
var state_3979__$1 = (function (){var statearr_3988 = state_3979;
(statearr_3988[(9)] = inst_3972);

return statearr_3988;
})();
var statearr_3989_4051 = state_3979__$1;
(statearr_3989_4051[(2)] = null);

(statearr_3989_4051[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (6))){
var inst_3944 = (state_3979[(7)]);
var state_3979__$1 = state_3979;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_3979__$1,(11),inst_3944);
} else {
if((state_val_3980 === (17))){
var inst_3965 = (state_3979[(2)]);
var state_3979__$1 = state_3979;
if(cljs.core.truth_(inst_3965)){
var statearr_3990_4052 = state_3979__$1;
(statearr_3990_4052[(1)] = (19));

} else {
var statearr_3991_4053 = state_3979__$1;
(statearr_3991_4053[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (3))){
var inst_3977 = (state_3979[(2)]);
var state_3979__$1 = state_3979;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_3979__$1,inst_3977);
} else {
if((state_val_3980 === (12))){
var inst_3954 = (state_3979[(10)]);
var state_3979__$1 = state_3979;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_3979__$1,(14),inst_3954);
} else {
if((state_val_3980 === (2))){
var state_3979__$1 = state_3979;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_3979__$1,(4),results);
} else {
if((state_val_3980 === (19))){
var state_3979__$1 = state_3979;
var statearr_3992_4054 = state_3979__$1;
(statearr_3992_4054[(2)] = null);

(statearr_3992_4054[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (11))){
var inst_3954 = (state_3979[(2)]);
var state_3979__$1 = (function (){var statearr_3993 = state_3979;
(statearr_3993[(10)] = inst_3954);

return statearr_3993;
})();
var statearr_3994_4055 = state_3979__$1;
(statearr_3994_4055[(2)] = null);

(statearr_3994_4055[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (9))){
var state_3979__$1 = state_3979;
var statearr_3995_4056 = state_3979__$1;
(statearr_3995_4056[(2)] = null);

(statearr_3995_4056[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (5))){
var state_3979__$1 = state_3979;
if(cljs.core.truth_(close_QMARK_)){
var statearr_3996_4057 = state_3979__$1;
(statearr_3996_4057[(1)] = (8));

} else {
var statearr_3997_4058 = state_3979__$1;
(statearr_3997_4058[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (14))){
var inst_3957 = (state_3979[(8)]);
var inst_3959 = (state_3979[(11)]);
var inst_3957__$1 = (state_3979[(2)]);
var inst_3958 = (inst_3957__$1 == null);
var inst_3959__$1 = cljs.core.not.call(null,inst_3958);
var state_3979__$1 = (function (){var statearr_3998 = state_3979;
(statearr_3998[(8)] = inst_3957__$1);

(statearr_3998[(11)] = inst_3959__$1);

return statearr_3998;
})();
if(inst_3959__$1){
var statearr_3999_4059 = state_3979__$1;
(statearr_3999_4059[(1)] = (15));

} else {
var statearr_4000_4060 = state_3979__$1;
(statearr_4000_4060[(1)] = (16));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (16))){
var inst_3959 = (state_3979[(11)]);
var state_3979__$1 = state_3979;
var statearr_4001_4061 = state_3979__$1;
(statearr_4001_4061[(2)] = inst_3959);

(statearr_4001_4061[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (10))){
var inst_3951 = (state_3979[(2)]);
var state_3979__$1 = state_3979;
var statearr_4002_4062 = state_3979__$1;
(statearr_4002_4062[(2)] = inst_3951);

(statearr_4002_4062[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (18))){
var inst_3962 = (state_3979[(2)]);
var state_3979__$1 = state_3979;
var statearr_4003_4063 = state_3979__$1;
(statearr_4003_4063[(2)] = inst_3962);

(statearr_4003_4063[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_3980 === (8))){
var inst_3948 = cljs.core.async.close_BANG_.call(null,to);
var state_3979__$1 = state_3979;
var statearr_4004_4064 = state_3979__$1;
(statearr_4004_4064[(2)] = inst_3948);

(statearr_4004_4064[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto__,jobs,results,process,async))
;
return ((function (switch__3583__auto__,c__3673__auto__,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0 = (function (){
var statearr_4005 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_4005[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__);

(statearr_4005[(1)] = (1));

return statearr_4005;
});
var cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1 = (function (state_3979){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_3979);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e4006){if((e4006 instanceof Object)){
var ex__3587__auto__ = e4006;
var statearr_4007_4065 = state_3979;
(statearr_4007_4065[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_3979);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e4006;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4066 = state_3979;
state_3979 = G__4066;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__ = function(state_3979){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1.call(this,state_3979);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__3584__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto__,jobs,results,process,async))
})();
var state__3675__auto__ = (function (){var statearr_4008 = f__3674__auto__.call(null);
(statearr_4008[(6)] = c__3673__auto__);

return statearr_4008;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto__,jobs,results,process,async))
);

return c__3673__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var G__4068 = arguments.length;
switch (G__4068) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.call(null,n,to,af,from,true);
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_.call(null,n,to,af,from,close_QMARK_,null,new cljs.core.Keyword(null,"async","async",1050769601));
});

cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5;

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var G__4071 = arguments.length;
switch (G__4071) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.call(null,n,to,xf,from,true);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.call(null,n,to,xf,from,close_QMARK_,null);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_.call(null,n,to,xf,from,close_QMARK_,ex_handler,new cljs.core.Keyword(null,"compute","compute",1555393130));
});

cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6;

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var G__4074 = arguments.length;
switch (G__4074) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.call(null,p,ch,null,null);
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.call(null,t_buf_or_n);
var fc = cljs.core.async.chan.call(null,f_buf_or_n);
var c__3673__auto___4123 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___4123,tc,fc){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___4123,tc,fc){
return (function (state_4100){
var state_val_4101 = (state_4100[(1)]);
if((state_val_4101 === (7))){
var inst_4096 = (state_4100[(2)]);
var state_4100__$1 = state_4100;
var statearr_4102_4124 = state_4100__$1;
(statearr_4102_4124[(2)] = inst_4096);

(statearr_4102_4124[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4101 === (1))){
var state_4100__$1 = state_4100;
var statearr_4103_4125 = state_4100__$1;
(statearr_4103_4125[(2)] = null);

(statearr_4103_4125[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4101 === (4))){
var inst_4077 = (state_4100[(7)]);
var inst_4077__$1 = (state_4100[(2)]);
var inst_4078 = (inst_4077__$1 == null);
var state_4100__$1 = (function (){var statearr_4104 = state_4100;
(statearr_4104[(7)] = inst_4077__$1);

return statearr_4104;
})();
if(cljs.core.truth_(inst_4078)){
var statearr_4105_4126 = state_4100__$1;
(statearr_4105_4126[(1)] = (5));

} else {
var statearr_4106_4127 = state_4100__$1;
(statearr_4106_4127[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4101 === (13))){
var state_4100__$1 = state_4100;
var statearr_4107_4128 = state_4100__$1;
(statearr_4107_4128[(2)] = null);

(statearr_4107_4128[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4101 === (6))){
var inst_4077 = (state_4100[(7)]);
var inst_4083 = p.call(null,inst_4077);
var state_4100__$1 = state_4100;
if(cljs.core.truth_(inst_4083)){
var statearr_4108_4129 = state_4100__$1;
(statearr_4108_4129[(1)] = (9));

} else {
var statearr_4109_4130 = state_4100__$1;
(statearr_4109_4130[(1)] = (10));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4101 === (3))){
var inst_4098 = (state_4100[(2)]);
var state_4100__$1 = state_4100;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_4100__$1,inst_4098);
} else {
if((state_val_4101 === (12))){
var state_4100__$1 = state_4100;
var statearr_4110_4131 = state_4100__$1;
(statearr_4110_4131[(2)] = null);

(statearr_4110_4131[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4101 === (2))){
var state_4100__$1 = state_4100;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_4100__$1,(4),ch);
} else {
if((state_val_4101 === (11))){
var inst_4077 = (state_4100[(7)]);
var inst_4087 = (state_4100[(2)]);
var state_4100__$1 = state_4100;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_4100__$1,(8),inst_4087,inst_4077);
} else {
if((state_val_4101 === (9))){
var state_4100__$1 = state_4100;
var statearr_4111_4132 = state_4100__$1;
(statearr_4111_4132[(2)] = tc);

(statearr_4111_4132[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4101 === (5))){
var inst_4080 = cljs.core.async.close_BANG_.call(null,tc);
var inst_4081 = cljs.core.async.close_BANG_.call(null,fc);
var state_4100__$1 = (function (){var statearr_4112 = state_4100;
(statearr_4112[(8)] = inst_4080);

return statearr_4112;
})();
var statearr_4113_4133 = state_4100__$1;
(statearr_4113_4133[(2)] = inst_4081);

(statearr_4113_4133[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4101 === (14))){
var inst_4094 = (state_4100[(2)]);
var state_4100__$1 = state_4100;
var statearr_4114_4134 = state_4100__$1;
(statearr_4114_4134[(2)] = inst_4094);

(statearr_4114_4134[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4101 === (10))){
var state_4100__$1 = state_4100;
var statearr_4115_4135 = state_4100__$1;
(statearr_4115_4135[(2)] = fc);

(statearr_4115_4135[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4101 === (8))){
var inst_4089 = (state_4100[(2)]);
var state_4100__$1 = state_4100;
if(cljs.core.truth_(inst_4089)){
var statearr_4116_4136 = state_4100__$1;
(statearr_4116_4136[(1)] = (12));

} else {
var statearr_4117_4137 = state_4100__$1;
(statearr_4117_4137[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___4123,tc,fc))
;
return ((function (switch__3583__auto__,c__3673__auto___4123,tc,fc){
return (function() {
var cljs$core$async$state_machine__3584__auto__ = null;
var cljs$core$async$state_machine__3584__auto____0 = (function (){
var statearr_4118 = [null,null,null,null,null,null,null,null,null];
(statearr_4118[(0)] = cljs$core$async$state_machine__3584__auto__);

(statearr_4118[(1)] = (1));

return statearr_4118;
});
var cljs$core$async$state_machine__3584__auto____1 = (function (state_4100){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_4100);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e4119){if((e4119 instanceof Object)){
var ex__3587__auto__ = e4119;
var statearr_4120_4138 = state_4100;
(statearr_4120_4138[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_4100);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e4119;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4139 = state_4100;
state_4100 = G__4139;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$state_machine__3584__auto__ = function(state_4100){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__3584__auto____1.call(this,state_4100);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__3584__auto____0;
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__3584__auto____1;
return cljs$core$async$state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___4123,tc,fc))
})();
var state__3675__auto__ = (function (){var statearr_4121 = f__3674__auto__.call(null);
(statearr_4121[(6)] = c__3673__auto___4123);

return statearr_4121;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___4123,tc,fc))
);


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
});

cljs.core.async.split.cljs$lang$maxFixedArity = 4;

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__3673__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto__){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto__){
return (function (state_4160){
var state_val_4161 = (state_4160[(1)]);
if((state_val_4161 === (7))){
var inst_4156 = (state_4160[(2)]);
var state_4160__$1 = state_4160;
var statearr_4162_4180 = state_4160__$1;
(statearr_4162_4180[(2)] = inst_4156);

(statearr_4162_4180[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4161 === (1))){
var inst_4140 = init;
var state_4160__$1 = (function (){var statearr_4163 = state_4160;
(statearr_4163[(7)] = inst_4140);

return statearr_4163;
})();
var statearr_4164_4181 = state_4160__$1;
(statearr_4164_4181[(2)] = null);

(statearr_4164_4181[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4161 === (4))){
var inst_4143 = (state_4160[(8)]);
var inst_4143__$1 = (state_4160[(2)]);
var inst_4144 = (inst_4143__$1 == null);
var state_4160__$1 = (function (){var statearr_4165 = state_4160;
(statearr_4165[(8)] = inst_4143__$1);

return statearr_4165;
})();
if(cljs.core.truth_(inst_4144)){
var statearr_4166_4182 = state_4160__$1;
(statearr_4166_4182[(1)] = (5));

} else {
var statearr_4167_4183 = state_4160__$1;
(statearr_4167_4183[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4161 === (6))){
var inst_4147 = (state_4160[(9)]);
var inst_4140 = (state_4160[(7)]);
var inst_4143 = (state_4160[(8)]);
var inst_4147__$1 = f.call(null,inst_4140,inst_4143);
var inst_4148 = cljs.core.reduced_QMARK_.call(null,inst_4147__$1);
var state_4160__$1 = (function (){var statearr_4168 = state_4160;
(statearr_4168[(9)] = inst_4147__$1);

return statearr_4168;
})();
if(inst_4148){
var statearr_4169_4184 = state_4160__$1;
(statearr_4169_4184[(1)] = (8));

} else {
var statearr_4170_4185 = state_4160__$1;
(statearr_4170_4185[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4161 === (3))){
var inst_4158 = (state_4160[(2)]);
var state_4160__$1 = state_4160;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_4160__$1,inst_4158);
} else {
if((state_val_4161 === (2))){
var state_4160__$1 = state_4160;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_4160__$1,(4),ch);
} else {
if((state_val_4161 === (9))){
var inst_4147 = (state_4160[(9)]);
var inst_4140 = inst_4147;
var state_4160__$1 = (function (){var statearr_4171 = state_4160;
(statearr_4171[(7)] = inst_4140);

return statearr_4171;
})();
var statearr_4172_4186 = state_4160__$1;
(statearr_4172_4186[(2)] = null);

(statearr_4172_4186[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4161 === (5))){
var inst_4140 = (state_4160[(7)]);
var state_4160__$1 = state_4160;
var statearr_4173_4187 = state_4160__$1;
(statearr_4173_4187[(2)] = inst_4140);

(statearr_4173_4187[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4161 === (10))){
var inst_4154 = (state_4160[(2)]);
var state_4160__$1 = state_4160;
var statearr_4174_4188 = state_4160__$1;
(statearr_4174_4188[(2)] = inst_4154);

(statearr_4174_4188[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4161 === (8))){
var inst_4147 = (state_4160[(9)]);
var inst_4150 = cljs.core.deref.call(null,inst_4147);
var state_4160__$1 = state_4160;
var statearr_4175_4189 = state_4160__$1;
(statearr_4175_4189[(2)] = inst_4150);

(statearr_4175_4189[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto__))
;
return ((function (switch__3583__auto__,c__3673__auto__){
return (function() {
var cljs$core$async$reduce_$_state_machine__3584__auto__ = null;
var cljs$core$async$reduce_$_state_machine__3584__auto____0 = (function (){
var statearr_4176 = [null,null,null,null,null,null,null,null,null,null];
(statearr_4176[(0)] = cljs$core$async$reduce_$_state_machine__3584__auto__);

(statearr_4176[(1)] = (1));

return statearr_4176;
});
var cljs$core$async$reduce_$_state_machine__3584__auto____1 = (function (state_4160){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_4160);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e4177){if((e4177 instanceof Object)){
var ex__3587__auto__ = e4177;
var statearr_4178_4190 = state_4160;
(statearr_4178_4190[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_4160);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e4177;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4191 = state_4160;
state_4160 = G__4191;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__3584__auto__ = function(state_4160){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__3584__auto____1.call(this,state_4160);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$reduce_$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__3584__auto____0;
cljs$core$async$reduce_$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__3584__auto____1;
return cljs$core$async$reduce_$_state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto__))
})();
var state__3675__auto__ = (function (){var statearr_4179 = f__3674__auto__.call(null);
(statearr_4179[(6)] = c__3673__auto__);

return statearr_4179;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto__))
);

return c__3673__auto__;
});
/**
 * async/reduces a channel with a transformation (xform f).
 *   Returns a channel containing the result.  ch must close before
 *   transduce produces a result.
 */
cljs.core.async.transduce = (function cljs$core$async$transduce(xform,f,init,ch){
var f__$1 = xform.call(null,f);
var c__3673__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto__,f__$1){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto__,f__$1){
return (function (state_4197){
var state_val_4198 = (state_4197[(1)]);
if((state_val_4198 === (1))){
var inst_4192 = cljs.core.async.reduce.call(null,f__$1,init,ch);
var state_4197__$1 = state_4197;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_4197__$1,(2),inst_4192);
} else {
if((state_val_4198 === (2))){
var inst_4194 = (state_4197[(2)]);
var inst_4195 = f__$1.call(null,inst_4194);
var state_4197__$1 = state_4197;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_4197__$1,inst_4195);
} else {
return null;
}
}
});})(c__3673__auto__,f__$1))
;
return ((function (switch__3583__auto__,c__3673__auto__,f__$1){
return (function() {
var cljs$core$async$transduce_$_state_machine__3584__auto__ = null;
var cljs$core$async$transduce_$_state_machine__3584__auto____0 = (function (){
var statearr_4199 = [null,null,null,null,null,null,null];
(statearr_4199[(0)] = cljs$core$async$transduce_$_state_machine__3584__auto__);

(statearr_4199[(1)] = (1));

return statearr_4199;
});
var cljs$core$async$transduce_$_state_machine__3584__auto____1 = (function (state_4197){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_4197);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e4200){if((e4200 instanceof Object)){
var ex__3587__auto__ = e4200;
var statearr_4201_4203 = state_4197;
(statearr_4201_4203[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_4197);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e4200;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4204 = state_4197;
state_4197 = G__4204;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$transduce_$_state_machine__3584__auto__ = function(state_4197){
switch(arguments.length){
case 0:
return cljs$core$async$transduce_$_state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$transduce_$_state_machine__3584__auto____1.call(this,state_4197);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$transduce_$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$transduce_$_state_machine__3584__auto____0;
cljs$core$async$transduce_$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$transduce_$_state_machine__3584__auto____1;
return cljs$core$async$transduce_$_state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto__,f__$1))
})();
var state__3675__auto__ = (function (){var statearr_4202 = f__3674__auto__.call(null);
(statearr_4202[(6)] = c__3673__auto__);

return statearr_4202;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto__,f__$1))
);

return c__3673__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var G__4206 = arguments.length;
switch (G__4206) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.call(null,ch,coll,true);
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__3673__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto__){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto__){
return (function (state_4231){
var state_val_4232 = (state_4231[(1)]);
if((state_val_4232 === (7))){
var inst_4213 = (state_4231[(2)]);
var state_4231__$1 = state_4231;
var statearr_4233_4254 = state_4231__$1;
(statearr_4233_4254[(2)] = inst_4213);

(statearr_4233_4254[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4232 === (1))){
var inst_4207 = cljs.core.seq.call(null,coll);
var inst_4208 = inst_4207;
var state_4231__$1 = (function (){var statearr_4234 = state_4231;
(statearr_4234[(7)] = inst_4208);

return statearr_4234;
})();
var statearr_4235_4255 = state_4231__$1;
(statearr_4235_4255[(2)] = null);

(statearr_4235_4255[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4232 === (4))){
var inst_4208 = (state_4231[(7)]);
var inst_4211 = cljs.core.first.call(null,inst_4208);
var state_4231__$1 = state_4231;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_4231__$1,(7),ch,inst_4211);
} else {
if((state_val_4232 === (13))){
var inst_4225 = (state_4231[(2)]);
var state_4231__$1 = state_4231;
var statearr_4236_4256 = state_4231__$1;
(statearr_4236_4256[(2)] = inst_4225);

(statearr_4236_4256[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4232 === (6))){
var inst_4216 = (state_4231[(2)]);
var state_4231__$1 = state_4231;
if(cljs.core.truth_(inst_4216)){
var statearr_4237_4257 = state_4231__$1;
(statearr_4237_4257[(1)] = (8));

} else {
var statearr_4238_4258 = state_4231__$1;
(statearr_4238_4258[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4232 === (3))){
var inst_4229 = (state_4231[(2)]);
var state_4231__$1 = state_4231;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_4231__$1,inst_4229);
} else {
if((state_val_4232 === (12))){
var state_4231__$1 = state_4231;
var statearr_4239_4259 = state_4231__$1;
(statearr_4239_4259[(2)] = null);

(statearr_4239_4259[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4232 === (2))){
var inst_4208 = (state_4231[(7)]);
var state_4231__$1 = state_4231;
if(cljs.core.truth_(inst_4208)){
var statearr_4240_4260 = state_4231__$1;
(statearr_4240_4260[(1)] = (4));

} else {
var statearr_4241_4261 = state_4231__$1;
(statearr_4241_4261[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4232 === (11))){
var inst_4222 = cljs.core.async.close_BANG_.call(null,ch);
var state_4231__$1 = state_4231;
var statearr_4242_4262 = state_4231__$1;
(statearr_4242_4262[(2)] = inst_4222);

(statearr_4242_4262[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4232 === (9))){
var state_4231__$1 = state_4231;
if(cljs.core.truth_(close_QMARK_)){
var statearr_4243_4263 = state_4231__$1;
(statearr_4243_4263[(1)] = (11));

} else {
var statearr_4244_4264 = state_4231__$1;
(statearr_4244_4264[(1)] = (12));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4232 === (5))){
var inst_4208 = (state_4231[(7)]);
var state_4231__$1 = state_4231;
var statearr_4245_4265 = state_4231__$1;
(statearr_4245_4265[(2)] = inst_4208);

(statearr_4245_4265[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4232 === (10))){
var inst_4227 = (state_4231[(2)]);
var state_4231__$1 = state_4231;
var statearr_4246_4266 = state_4231__$1;
(statearr_4246_4266[(2)] = inst_4227);

(statearr_4246_4266[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4232 === (8))){
var inst_4208 = (state_4231[(7)]);
var inst_4218 = cljs.core.next.call(null,inst_4208);
var inst_4208__$1 = inst_4218;
var state_4231__$1 = (function (){var statearr_4247 = state_4231;
(statearr_4247[(7)] = inst_4208__$1);

return statearr_4247;
})();
var statearr_4248_4267 = state_4231__$1;
(statearr_4248_4267[(2)] = null);

(statearr_4248_4267[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto__))
;
return ((function (switch__3583__auto__,c__3673__auto__){
return (function() {
var cljs$core$async$state_machine__3584__auto__ = null;
var cljs$core$async$state_machine__3584__auto____0 = (function (){
var statearr_4249 = [null,null,null,null,null,null,null,null];
(statearr_4249[(0)] = cljs$core$async$state_machine__3584__auto__);

(statearr_4249[(1)] = (1));

return statearr_4249;
});
var cljs$core$async$state_machine__3584__auto____1 = (function (state_4231){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_4231);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e4250){if((e4250 instanceof Object)){
var ex__3587__auto__ = e4250;
var statearr_4251_4268 = state_4231;
(statearr_4251_4268[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_4231);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e4250;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4269 = state_4231;
state_4231 = G__4269;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$state_machine__3584__auto__ = function(state_4231){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__3584__auto____1.call(this,state_4231);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__3584__auto____0;
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__3584__auto____1;
return cljs$core$async$state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto__))
})();
var state__3675__auto__ = (function (){var statearr_4252 = f__3674__auto__.call(null);
(statearr_4252[(6)] = c__3673__auto__);

return statearr_4252;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto__))
);

return c__3673__auto__;
});

cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.call(null,cljs.core.bounded_count.call(null,(100),coll));
cljs.core.async.onto_chan.call(null,ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if(((!((_ == null))) && (!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null))))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__4211__auto__ = (((_ == null))?null:_);
var m__4212__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,_);
} else {
var m__4212__auto____$1 = (cljs.core.async.muxch_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,_);
} else {
throw cljs.core.missing_protocol.call(null,"Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if(((!((m == null))) && (!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null))))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__4211__auto__ = (((m == null))?null:m);
var m__4212__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,m,ch,close_QMARK_);
} else {
var m__4212__auto____$1 = (cljs.core.async.tap_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,m,ch,close_QMARK_);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if(((!((m == null))) && (!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null))))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__4211__auto__ = (((m == null))?null:m);
var m__4212__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,m,ch);
} else {
var m__4212__auto____$1 = (cljs.core.async.untap_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if(((!((m == null))) && (!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null))))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__4211__auto__ = (((m == null))?null:m);
var m__4212__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,m);
} else {
var m__4212__auto____$1 = (cljs.core.async.untap_all_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,m);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var m = (function (){
if(typeof cljs.core.async.t_cljs$core$async4270 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async4270 = (function (ch,cs,meta4271){
this.ch = ch;
this.cs = cs;
this.meta4271 = meta4271;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async4270.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs){
return (function (_4272,meta4271__$1){
var self__ = this;
var _4272__$1 = this;
return (new cljs.core.async.t_cljs$core$async4270(self__.ch,self__.cs,meta4271__$1));
});})(cs))
;

cljs.core.async.t_cljs$core$async4270.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs){
return (function (_4272){
var self__ = this;
var _4272__$1 = this;
return self__.meta4271;
});})(cs))
;

cljs.core.async.t_cljs$core$async4270.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async4270.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(cs))
;

cljs.core.async.t_cljs$core$async4270.prototype.cljs$core$async$Mult$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async4270.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = ((function (cs){
return (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async4270.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = ((function (cs){
return (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.dissoc,ch__$1);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async4270.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async4270.getBasis = ((function (cs){
return (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"cs","cs",-117024463,null),new cljs.core.Symbol(null,"meta4271","meta4271",1427530480,null)], null);
});})(cs))
;

cljs.core.async.t_cljs$core$async4270.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async4270.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async4270";

cljs.core.async.t_cljs$core$async4270.cljs$lang$ctorPrWriter = ((function (cs){
return (function (this__4161__auto__,writer__4162__auto__,opt__4163__auto__){
return cljs.core._write.call(null,writer__4162__auto__,"cljs.core.async/t_cljs$core$async4270");
});})(cs))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async4270.
 */
cljs.core.async.__GT_t_cljs$core$async4270 = ((function (cs){
return (function cljs$core$async$mult_$___GT_t_cljs$core$async4270(ch__$1,cs__$1,meta4271){
return (new cljs.core.async.t_cljs$core$async4270(ch__$1,cs__$1,meta4271));
});})(cs))
;

}

return (new cljs.core.async.t_cljs$core$async4270(ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.call(null,(1));
var dctr = cljs.core.atom.call(null,null);
var done = ((function (cs,m,dchan,dctr){
return (function (_){
if((cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.call(null,dchan,true);
} else {
return null;
}
});})(cs,m,dchan,dctr))
;
var c__3673__auto___4492 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___4492,cs,m,dchan,dctr,done){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___4492,cs,m,dchan,dctr,done){
return (function (state_4407){
var state_val_4408 = (state_4407[(1)]);
if((state_val_4408 === (7))){
var inst_4403 = (state_4407[(2)]);
var state_4407__$1 = state_4407;
var statearr_4409_4493 = state_4407__$1;
(statearr_4409_4493[(2)] = inst_4403);

(statearr_4409_4493[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (20))){
var inst_4306 = (state_4407[(7)]);
var inst_4318 = cljs.core.first.call(null,inst_4306);
var inst_4319 = cljs.core.nth.call(null,inst_4318,(0),null);
var inst_4320 = cljs.core.nth.call(null,inst_4318,(1),null);
var state_4407__$1 = (function (){var statearr_4410 = state_4407;
(statearr_4410[(8)] = inst_4319);

return statearr_4410;
})();
if(cljs.core.truth_(inst_4320)){
var statearr_4411_4494 = state_4407__$1;
(statearr_4411_4494[(1)] = (22));

} else {
var statearr_4412_4495 = state_4407__$1;
(statearr_4412_4495[(1)] = (23));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (27))){
var inst_4350 = (state_4407[(9)]);
var inst_4275 = (state_4407[(10)]);
var inst_4348 = (state_4407[(11)]);
var inst_4355 = (state_4407[(12)]);
var inst_4355__$1 = cljs.core._nth.call(null,inst_4348,inst_4350);
var inst_4356 = cljs.core.async.put_BANG_.call(null,inst_4355__$1,inst_4275,done);
var state_4407__$1 = (function (){var statearr_4413 = state_4407;
(statearr_4413[(12)] = inst_4355__$1);

return statearr_4413;
})();
if(cljs.core.truth_(inst_4356)){
var statearr_4414_4496 = state_4407__$1;
(statearr_4414_4496[(1)] = (30));

} else {
var statearr_4415_4497 = state_4407__$1;
(statearr_4415_4497[(1)] = (31));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (1))){
var state_4407__$1 = state_4407;
var statearr_4416_4498 = state_4407__$1;
(statearr_4416_4498[(2)] = null);

(statearr_4416_4498[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (24))){
var inst_4306 = (state_4407[(7)]);
var inst_4325 = (state_4407[(2)]);
var inst_4326 = cljs.core.next.call(null,inst_4306);
var inst_4284 = inst_4326;
var inst_4285 = null;
var inst_4286 = (0);
var inst_4287 = (0);
var state_4407__$1 = (function (){var statearr_4417 = state_4407;
(statearr_4417[(13)] = inst_4284);

(statearr_4417[(14)] = inst_4287);

(statearr_4417[(15)] = inst_4325);

(statearr_4417[(16)] = inst_4286);

(statearr_4417[(17)] = inst_4285);

return statearr_4417;
})();
var statearr_4418_4499 = state_4407__$1;
(statearr_4418_4499[(2)] = null);

(statearr_4418_4499[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (39))){
var state_4407__$1 = state_4407;
var statearr_4422_4500 = state_4407__$1;
(statearr_4422_4500[(2)] = null);

(statearr_4422_4500[(1)] = (41));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (4))){
var inst_4275 = (state_4407[(10)]);
var inst_4275__$1 = (state_4407[(2)]);
var inst_4276 = (inst_4275__$1 == null);
var state_4407__$1 = (function (){var statearr_4423 = state_4407;
(statearr_4423[(10)] = inst_4275__$1);

return statearr_4423;
})();
if(cljs.core.truth_(inst_4276)){
var statearr_4424_4501 = state_4407__$1;
(statearr_4424_4501[(1)] = (5));

} else {
var statearr_4425_4502 = state_4407__$1;
(statearr_4425_4502[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (15))){
var inst_4284 = (state_4407[(13)]);
var inst_4287 = (state_4407[(14)]);
var inst_4286 = (state_4407[(16)]);
var inst_4285 = (state_4407[(17)]);
var inst_4302 = (state_4407[(2)]);
var inst_4303 = (inst_4287 + (1));
var tmp4419 = inst_4284;
var tmp4420 = inst_4286;
var tmp4421 = inst_4285;
var inst_4284__$1 = tmp4419;
var inst_4285__$1 = tmp4421;
var inst_4286__$1 = tmp4420;
var inst_4287__$1 = inst_4303;
var state_4407__$1 = (function (){var statearr_4426 = state_4407;
(statearr_4426[(18)] = inst_4302);

(statearr_4426[(13)] = inst_4284__$1);

(statearr_4426[(14)] = inst_4287__$1);

(statearr_4426[(16)] = inst_4286__$1);

(statearr_4426[(17)] = inst_4285__$1);

return statearr_4426;
})();
var statearr_4427_4503 = state_4407__$1;
(statearr_4427_4503[(2)] = null);

(statearr_4427_4503[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (21))){
var inst_4329 = (state_4407[(2)]);
var state_4407__$1 = state_4407;
var statearr_4431_4504 = state_4407__$1;
(statearr_4431_4504[(2)] = inst_4329);

(statearr_4431_4504[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (31))){
var inst_4355 = (state_4407[(12)]);
var inst_4359 = done.call(null,null);
var inst_4360 = cljs.core.async.untap_STAR_.call(null,m,inst_4355);
var state_4407__$1 = (function (){var statearr_4432 = state_4407;
(statearr_4432[(19)] = inst_4359);

return statearr_4432;
})();
var statearr_4433_4505 = state_4407__$1;
(statearr_4433_4505[(2)] = inst_4360);

(statearr_4433_4505[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (32))){
var inst_4350 = (state_4407[(9)]);
var inst_4347 = (state_4407[(20)]);
var inst_4348 = (state_4407[(11)]);
var inst_4349 = (state_4407[(21)]);
var inst_4362 = (state_4407[(2)]);
var inst_4363 = (inst_4350 + (1));
var tmp4428 = inst_4347;
var tmp4429 = inst_4348;
var tmp4430 = inst_4349;
var inst_4347__$1 = tmp4428;
var inst_4348__$1 = tmp4429;
var inst_4349__$1 = tmp4430;
var inst_4350__$1 = inst_4363;
var state_4407__$1 = (function (){var statearr_4434 = state_4407;
(statearr_4434[(22)] = inst_4362);

(statearr_4434[(9)] = inst_4350__$1);

(statearr_4434[(20)] = inst_4347__$1);

(statearr_4434[(11)] = inst_4348__$1);

(statearr_4434[(21)] = inst_4349__$1);

return statearr_4434;
})();
var statearr_4435_4506 = state_4407__$1;
(statearr_4435_4506[(2)] = null);

(statearr_4435_4506[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (40))){
var inst_4375 = (state_4407[(23)]);
var inst_4379 = done.call(null,null);
var inst_4380 = cljs.core.async.untap_STAR_.call(null,m,inst_4375);
var state_4407__$1 = (function (){var statearr_4436 = state_4407;
(statearr_4436[(24)] = inst_4379);

return statearr_4436;
})();
var statearr_4437_4507 = state_4407__$1;
(statearr_4437_4507[(2)] = inst_4380);

(statearr_4437_4507[(1)] = (41));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (33))){
var inst_4366 = (state_4407[(25)]);
var inst_4368 = cljs.core.chunked_seq_QMARK_.call(null,inst_4366);
var state_4407__$1 = state_4407;
if(inst_4368){
var statearr_4438_4508 = state_4407__$1;
(statearr_4438_4508[(1)] = (36));

} else {
var statearr_4439_4509 = state_4407__$1;
(statearr_4439_4509[(1)] = (37));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (13))){
var inst_4296 = (state_4407[(26)]);
var inst_4299 = cljs.core.async.close_BANG_.call(null,inst_4296);
var state_4407__$1 = state_4407;
var statearr_4440_4510 = state_4407__$1;
(statearr_4440_4510[(2)] = inst_4299);

(statearr_4440_4510[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (22))){
var inst_4319 = (state_4407[(8)]);
var inst_4322 = cljs.core.async.close_BANG_.call(null,inst_4319);
var state_4407__$1 = state_4407;
var statearr_4441_4511 = state_4407__$1;
(statearr_4441_4511[(2)] = inst_4322);

(statearr_4441_4511[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (36))){
var inst_4366 = (state_4407[(25)]);
var inst_4370 = cljs.core.chunk_first.call(null,inst_4366);
var inst_4371 = cljs.core.chunk_rest.call(null,inst_4366);
var inst_4372 = cljs.core.count.call(null,inst_4370);
var inst_4347 = inst_4371;
var inst_4348 = inst_4370;
var inst_4349 = inst_4372;
var inst_4350 = (0);
var state_4407__$1 = (function (){var statearr_4442 = state_4407;
(statearr_4442[(9)] = inst_4350);

(statearr_4442[(20)] = inst_4347);

(statearr_4442[(11)] = inst_4348);

(statearr_4442[(21)] = inst_4349);

return statearr_4442;
})();
var statearr_4443_4512 = state_4407__$1;
(statearr_4443_4512[(2)] = null);

(statearr_4443_4512[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (41))){
var inst_4366 = (state_4407[(25)]);
var inst_4382 = (state_4407[(2)]);
var inst_4383 = cljs.core.next.call(null,inst_4366);
var inst_4347 = inst_4383;
var inst_4348 = null;
var inst_4349 = (0);
var inst_4350 = (0);
var state_4407__$1 = (function (){var statearr_4444 = state_4407;
(statearr_4444[(9)] = inst_4350);

(statearr_4444[(20)] = inst_4347);

(statearr_4444[(27)] = inst_4382);

(statearr_4444[(11)] = inst_4348);

(statearr_4444[(21)] = inst_4349);

return statearr_4444;
})();
var statearr_4445_4513 = state_4407__$1;
(statearr_4445_4513[(2)] = null);

(statearr_4445_4513[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (43))){
var state_4407__$1 = state_4407;
var statearr_4446_4514 = state_4407__$1;
(statearr_4446_4514[(2)] = null);

(statearr_4446_4514[(1)] = (44));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (29))){
var inst_4391 = (state_4407[(2)]);
var state_4407__$1 = state_4407;
var statearr_4447_4515 = state_4407__$1;
(statearr_4447_4515[(2)] = inst_4391);

(statearr_4447_4515[(1)] = (26));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (44))){
var inst_4400 = (state_4407[(2)]);
var state_4407__$1 = (function (){var statearr_4448 = state_4407;
(statearr_4448[(28)] = inst_4400);

return statearr_4448;
})();
var statearr_4449_4516 = state_4407__$1;
(statearr_4449_4516[(2)] = null);

(statearr_4449_4516[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (6))){
var inst_4339 = (state_4407[(29)]);
var inst_4338 = cljs.core.deref.call(null,cs);
var inst_4339__$1 = cljs.core.keys.call(null,inst_4338);
var inst_4340 = cljs.core.count.call(null,inst_4339__$1);
var inst_4341 = cljs.core.reset_BANG_.call(null,dctr,inst_4340);
var inst_4346 = cljs.core.seq.call(null,inst_4339__$1);
var inst_4347 = inst_4346;
var inst_4348 = null;
var inst_4349 = (0);
var inst_4350 = (0);
var state_4407__$1 = (function (){var statearr_4450 = state_4407;
(statearr_4450[(9)] = inst_4350);

(statearr_4450[(20)] = inst_4347);

(statearr_4450[(30)] = inst_4341);

(statearr_4450[(29)] = inst_4339__$1);

(statearr_4450[(11)] = inst_4348);

(statearr_4450[(21)] = inst_4349);

return statearr_4450;
})();
var statearr_4451_4517 = state_4407__$1;
(statearr_4451_4517[(2)] = null);

(statearr_4451_4517[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (28))){
var inst_4347 = (state_4407[(20)]);
var inst_4366 = (state_4407[(25)]);
var inst_4366__$1 = cljs.core.seq.call(null,inst_4347);
var state_4407__$1 = (function (){var statearr_4452 = state_4407;
(statearr_4452[(25)] = inst_4366__$1);

return statearr_4452;
})();
if(inst_4366__$1){
var statearr_4453_4518 = state_4407__$1;
(statearr_4453_4518[(1)] = (33));

} else {
var statearr_4454_4519 = state_4407__$1;
(statearr_4454_4519[(1)] = (34));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (25))){
var inst_4350 = (state_4407[(9)]);
var inst_4349 = (state_4407[(21)]);
var inst_4352 = (inst_4350 < inst_4349);
var inst_4353 = inst_4352;
var state_4407__$1 = state_4407;
if(cljs.core.truth_(inst_4353)){
var statearr_4455_4520 = state_4407__$1;
(statearr_4455_4520[(1)] = (27));

} else {
var statearr_4456_4521 = state_4407__$1;
(statearr_4456_4521[(1)] = (28));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (34))){
var state_4407__$1 = state_4407;
var statearr_4457_4522 = state_4407__$1;
(statearr_4457_4522[(2)] = null);

(statearr_4457_4522[(1)] = (35));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (17))){
var state_4407__$1 = state_4407;
var statearr_4458_4523 = state_4407__$1;
(statearr_4458_4523[(2)] = null);

(statearr_4458_4523[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (3))){
var inst_4405 = (state_4407[(2)]);
var state_4407__$1 = state_4407;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_4407__$1,inst_4405);
} else {
if((state_val_4408 === (12))){
var inst_4334 = (state_4407[(2)]);
var state_4407__$1 = state_4407;
var statearr_4459_4524 = state_4407__$1;
(statearr_4459_4524[(2)] = inst_4334);

(statearr_4459_4524[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (2))){
var state_4407__$1 = state_4407;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_4407__$1,(4),ch);
} else {
if((state_val_4408 === (23))){
var state_4407__$1 = state_4407;
var statearr_4460_4525 = state_4407__$1;
(statearr_4460_4525[(2)] = null);

(statearr_4460_4525[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (35))){
var inst_4389 = (state_4407[(2)]);
var state_4407__$1 = state_4407;
var statearr_4461_4526 = state_4407__$1;
(statearr_4461_4526[(2)] = inst_4389);

(statearr_4461_4526[(1)] = (29));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (19))){
var inst_4306 = (state_4407[(7)]);
var inst_4310 = cljs.core.chunk_first.call(null,inst_4306);
var inst_4311 = cljs.core.chunk_rest.call(null,inst_4306);
var inst_4312 = cljs.core.count.call(null,inst_4310);
var inst_4284 = inst_4311;
var inst_4285 = inst_4310;
var inst_4286 = inst_4312;
var inst_4287 = (0);
var state_4407__$1 = (function (){var statearr_4462 = state_4407;
(statearr_4462[(13)] = inst_4284);

(statearr_4462[(14)] = inst_4287);

(statearr_4462[(16)] = inst_4286);

(statearr_4462[(17)] = inst_4285);

return statearr_4462;
})();
var statearr_4463_4527 = state_4407__$1;
(statearr_4463_4527[(2)] = null);

(statearr_4463_4527[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (11))){
var inst_4306 = (state_4407[(7)]);
var inst_4284 = (state_4407[(13)]);
var inst_4306__$1 = cljs.core.seq.call(null,inst_4284);
var state_4407__$1 = (function (){var statearr_4464 = state_4407;
(statearr_4464[(7)] = inst_4306__$1);

return statearr_4464;
})();
if(inst_4306__$1){
var statearr_4465_4528 = state_4407__$1;
(statearr_4465_4528[(1)] = (16));

} else {
var statearr_4466_4529 = state_4407__$1;
(statearr_4466_4529[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (9))){
var inst_4336 = (state_4407[(2)]);
var state_4407__$1 = state_4407;
var statearr_4467_4530 = state_4407__$1;
(statearr_4467_4530[(2)] = inst_4336);

(statearr_4467_4530[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (5))){
var inst_4282 = cljs.core.deref.call(null,cs);
var inst_4283 = cljs.core.seq.call(null,inst_4282);
var inst_4284 = inst_4283;
var inst_4285 = null;
var inst_4286 = (0);
var inst_4287 = (0);
var state_4407__$1 = (function (){var statearr_4468 = state_4407;
(statearr_4468[(13)] = inst_4284);

(statearr_4468[(14)] = inst_4287);

(statearr_4468[(16)] = inst_4286);

(statearr_4468[(17)] = inst_4285);

return statearr_4468;
})();
var statearr_4469_4531 = state_4407__$1;
(statearr_4469_4531[(2)] = null);

(statearr_4469_4531[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (14))){
var state_4407__$1 = state_4407;
var statearr_4470_4532 = state_4407__$1;
(statearr_4470_4532[(2)] = null);

(statearr_4470_4532[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (45))){
var inst_4397 = (state_4407[(2)]);
var state_4407__$1 = state_4407;
var statearr_4471_4533 = state_4407__$1;
(statearr_4471_4533[(2)] = inst_4397);

(statearr_4471_4533[(1)] = (44));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (26))){
var inst_4339 = (state_4407[(29)]);
var inst_4393 = (state_4407[(2)]);
var inst_4394 = cljs.core.seq.call(null,inst_4339);
var state_4407__$1 = (function (){var statearr_4472 = state_4407;
(statearr_4472[(31)] = inst_4393);

return statearr_4472;
})();
if(inst_4394){
var statearr_4473_4534 = state_4407__$1;
(statearr_4473_4534[(1)] = (42));

} else {
var statearr_4474_4535 = state_4407__$1;
(statearr_4474_4535[(1)] = (43));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (16))){
var inst_4306 = (state_4407[(7)]);
var inst_4308 = cljs.core.chunked_seq_QMARK_.call(null,inst_4306);
var state_4407__$1 = state_4407;
if(inst_4308){
var statearr_4475_4536 = state_4407__$1;
(statearr_4475_4536[(1)] = (19));

} else {
var statearr_4476_4537 = state_4407__$1;
(statearr_4476_4537[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (38))){
var inst_4386 = (state_4407[(2)]);
var state_4407__$1 = state_4407;
var statearr_4477_4538 = state_4407__$1;
(statearr_4477_4538[(2)] = inst_4386);

(statearr_4477_4538[(1)] = (35));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (30))){
var state_4407__$1 = state_4407;
var statearr_4478_4539 = state_4407__$1;
(statearr_4478_4539[(2)] = null);

(statearr_4478_4539[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (10))){
var inst_4287 = (state_4407[(14)]);
var inst_4285 = (state_4407[(17)]);
var inst_4295 = cljs.core._nth.call(null,inst_4285,inst_4287);
var inst_4296 = cljs.core.nth.call(null,inst_4295,(0),null);
var inst_4297 = cljs.core.nth.call(null,inst_4295,(1),null);
var state_4407__$1 = (function (){var statearr_4479 = state_4407;
(statearr_4479[(26)] = inst_4296);

return statearr_4479;
})();
if(cljs.core.truth_(inst_4297)){
var statearr_4480_4540 = state_4407__$1;
(statearr_4480_4540[(1)] = (13));

} else {
var statearr_4481_4541 = state_4407__$1;
(statearr_4481_4541[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (18))){
var inst_4332 = (state_4407[(2)]);
var state_4407__$1 = state_4407;
var statearr_4482_4542 = state_4407__$1;
(statearr_4482_4542[(2)] = inst_4332);

(statearr_4482_4542[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (42))){
var state_4407__$1 = state_4407;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_4407__$1,(45),dchan);
} else {
if((state_val_4408 === (37))){
var inst_4366 = (state_4407[(25)]);
var inst_4375 = (state_4407[(23)]);
var inst_4275 = (state_4407[(10)]);
var inst_4375__$1 = cljs.core.first.call(null,inst_4366);
var inst_4376 = cljs.core.async.put_BANG_.call(null,inst_4375__$1,inst_4275,done);
var state_4407__$1 = (function (){var statearr_4483 = state_4407;
(statearr_4483[(23)] = inst_4375__$1);

return statearr_4483;
})();
if(cljs.core.truth_(inst_4376)){
var statearr_4484_4543 = state_4407__$1;
(statearr_4484_4543[(1)] = (39));

} else {
var statearr_4485_4544 = state_4407__$1;
(statearr_4485_4544[(1)] = (40));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4408 === (8))){
var inst_4287 = (state_4407[(14)]);
var inst_4286 = (state_4407[(16)]);
var inst_4289 = (inst_4287 < inst_4286);
var inst_4290 = inst_4289;
var state_4407__$1 = state_4407;
if(cljs.core.truth_(inst_4290)){
var statearr_4486_4545 = state_4407__$1;
(statearr_4486_4545[(1)] = (10));

} else {
var statearr_4487_4546 = state_4407__$1;
(statearr_4487_4546[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___4492,cs,m,dchan,dctr,done))
;
return ((function (switch__3583__auto__,c__3673__auto___4492,cs,m,dchan,dctr,done){
return (function() {
var cljs$core$async$mult_$_state_machine__3584__auto__ = null;
var cljs$core$async$mult_$_state_machine__3584__auto____0 = (function (){
var statearr_4488 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_4488[(0)] = cljs$core$async$mult_$_state_machine__3584__auto__);

(statearr_4488[(1)] = (1));

return statearr_4488;
});
var cljs$core$async$mult_$_state_machine__3584__auto____1 = (function (state_4407){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_4407);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e4489){if((e4489 instanceof Object)){
var ex__3587__auto__ = e4489;
var statearr_4490_4547 = state_4407;
(statearr_4490_4547[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_4407);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e4489;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4548 = state_4407;
state_4407 = G__4548;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__3584__auto__ = function(state_4407){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__3584__auto____1.call(this,state_4407);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$mult_$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__3584__auto____0;
cljs$core$async$mult_$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__3584__auto____1;
return cljs$core$async$mult_$_state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___4492,cs,m,dchan,dctr,done))
})();
var state__3675__auto__ = (function (){var statearr_4491 = f__3674__auto__.call(null);
(statearr_4491[(6)] = c__3673__auto___4492);

return statearr_4491;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___4492,cs,m,dchan,dctr,done))
);


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var G__4550 = arguments.length;
switch (G__4550) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.call(null,mult,ch,true);
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_.call(null,mult,ch,close_QMARK_);

return ch;
});

cljs.core.async.tap.cljs$lang$maxFixedArity = 3;

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_.call(null,mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_.call(null,mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if(((!((m == null))) && (!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null))))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__4211__auto__ = (((m == null))?null:m);
var m__4212__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,m,ch);
} else {
var m__4212__auto____$1 = (cljs.core.async.admix_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if(((!((m == null))) && (!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null))))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__4211__auto__ = (((m == null))?null:m);
var m__4212__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,m,ch);
} else {
var m__4212__auto____$1 = (cljs.core.async.unmix_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if(((!((m == null))) && (!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null))))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__4211__auto__ = (((m == null))?null:m);
var m__4212__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,m);
} else {
var m__4212__auto____$1 = (cljs.core.async.unmix_all_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,m);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if(((!((m == null))) && (!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null))))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__4211__auto__ = (((m == null))?null:m);
var m__4212__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,m,state_map);
} else {
var m__4212__auto____$1 = (cljs.core.async.toggle_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,m,state_map);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if(((!((m == null))) && (!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null))))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__4211__auto__ = (((m == null))?null:m);
var m__4212__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,m,mode);
} else {
var m__4212__auto____$1 = (cljs.core.async.solo_mode_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,m,mode);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__4502__auto__ = [];
var len__4499__auto___4562 = arguments.length;
var i__4500__auto___4563 = (0);
while(true){
if((i__4500__auto___4563 < len__4499__auto___4562)){
args__4502__auto__.push((arguments[i__4500__auto___4563]));

var G__4564 = (i__4500__auto___4563 + (1));
i__4500__auto___4563 = G__4564;
continue;
} else {
}
break;
}

var argseq__4503__auto__ = ((((3) < args__4502__auto__.length))?(new cljs.core.IndexedSeq(args__4502__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4503__auto__);
});

cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__4556){
var map__4557 = p__4556;
var map__4557__$1 = ((((!((map__4557 == null)))?(((((map__4557.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__4557.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__4557):map__4557);
var opts = map__4557__$1;
var statearr_4559_4565 = state;
(statearr_4559_4565[(1)] = cont_block);


var temp__5457__auto__ = cljs.core.async.do_alts.call(null,((function (map__4557,map__4557__$1,opts){
return (function (val){
var statearr_4560_4566 = state;
(statearr_4560_4566[(2)] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state);
});})(map__4557,map__4557__$1,opts))
,ports,opts);
if(cljs.core.truth_(temp__5457__auto__)){
var cb = temp__5457__auto__;
var statearr_4561_4567 = state;
(statearr_4561_4567[(2)] = cljs.core.deref.call(null,cb));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
});

cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3);

/** @this {Function} */
cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq4552){
var G__4553 = cljs.core.first.call(null,seq4552);
var seq4552__$1 = cljs.core.next.call(null,seq4552);
var G__4554 = cljs.core.first.call(null,seq4552__$1);
var seq4552__$2 = cljs.core.next.call(null,seq4552__$1);
var G__4555 = cljs.core.first.call(null,seq4552__$2);
var seq4552__$3 = cljs.core.next.call(null,seq4552__$2);
var self__4486__auto__ = this;
return self__4486__auto__.cljs$core$IFn$_invoke$arity$variadic(G__4553,G__4554,G__4555,seq4552__$3);
});

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"pause","pause",-2095325672),null,new cljs.core.Keyword(null,"mute","mute",1151223646),null], null), null);
var attrs = cljs.core.conj.call(null,solo_modes,new cljs.core.Keyword(null,"solo","solo",-316350075));
var solo_mode = cljs.core.atom.call(null,new cljs.core.Keyword(null,"mute","mute",1151223646));
var change = cljs.core.async.chan.call(null);
var changed = ((function (cs,solo_modes,attrs,solo_mode,change){
return (function (){
return cljs.core.async.put_BANG_.call(null,change,true);
});})(cs,solo_modes,attrs,solo_mode,change))
;
var pick = ((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (attr,chs){
return cljs.core.reduce_kv.call(null,((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (ret,c,v){
if(cljs.core.truth_(attr.call(null,v))){
return cljs.core.conj.call(null,ret,c);
} else {
return ret;
}
});})(cs,solo_modes,attrs,solo_mode,change,changed))
,cljs.core.PersistentHashSet.EMPTY,chs);
});})(cs,solo_modes,attrs,solo_mode,change,changed))
;
var calc_state = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick){
return (function (){
var chs = cljs.core.deref.call(null,cs);
var mode = cljs.core.deref.call(null,solo_mode);
var solos = pick.call(null,new cljs.core.Keyword(null,"solo","solo",-316350075),chs);
var pauses = pick.call(null,new cljs.core.Keyword(null,"pause","pause",-2095325672),chs);
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"solos","solos",1441458643),solos,new cljs.core.Keyword(null,"mutes","mutes",1068806309),pick.call(null,new cljs.core.Keyword(null,"mute","mute",1151223646),chs),new cljs.core.Keyword(null,"reads","reads",-1215067361),cljs.core.conj.call(null,((((cljs.core._EQ_.call(null,mode,new cljs.core.Keyword(null,"pause","pause",-2095325672))) && (!(cljs.core.empty_QMARK_.call(null,solos)))))?cljs.core.vec.call(null,solos):cljs.core.vec.call(null,cljs.core.remove.call(null,pauses,cljs.core.keys.call(null,chs)))),change)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick))
;
var m = (function (){
if(typeof cljs.core.async.t_cljs$core$async4568 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async4568 = (function (out,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,meta4569){
this.out = out;
this.cs = cs;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.solo_mode = solo_mode;
this.change = change;
this.changed = changed;
this.pick = pick;
this.calc_state = calc_state;
this.meta4569 = meta4569;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async4568.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_4570,meta4569__$1){
var self__ = this;
var _4570__$1 = this;
return (new cljs.core.async.t_cljs$core$async4568(self__.out,self__.cs,self__.solo_modes,self__.attrs,self__.solo_mode,self__.change,self__.changed,self__.pick,self__.calc_state,meta4569__$1));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async4568.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_4570){
var self__ = this;
var _4570__$1 = this;
return self__.meta4569;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async4568.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async4568.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async4568.prototype.cljs$core$async$Mix$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async4568.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async4568.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.dissoc,ch);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async4568.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async4568.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.partial.call(null,cljs.core.merge_with,cljs.core.merge),state_map);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async4568.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,mode){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_(self__.solo_modes.call(null,mode))){
} else {
throw (new Error(["Assert failed: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(["mode must be one of: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(self__.solo_modes)].join('')),"\n","(solo-modes mode)"].join('')));
}

cljs.core.reset_BANG_.call(null,self__.solo_mode,mode);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async4568.getBasis = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (){
return new cljs.core.PersistentVector(null, 10, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"out","out",729986010,null),new cljs.core.Symbol(null,"cs","cs",-117024463,null),new cljs.core.Symbol(null,"solo-modes","solo-modes",882180540,null),new cljs.core.Symbol(null,"attrs","attrs",-450137186,null),new cljs.core.Symbol(null,"solo-mode","solo-mode",2031788074,null),new cljs.core.Symbol(null,"change","change",477485025,null),new cljs.core.Symbol(null,"changed","changed",-2083710852,null),new cljs.core.Symbol(null,"pick","pick",1300068175,null),new cljs.core.Symbol(null,"calc-state","calc-state",-349968968,null),new cljs.core.Symbol(null,"meta4569","meta4569",1160076332,null)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async4568.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async4568.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async4568";

cljs.core.async.t_cljs$core$async4568.cljs$lang$ctorPrWriter = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (this__4161__auto__,writer__4162__auto__,opt__4163__auto__){
return cljs.core._write.call(null,writer__4162__auto__,"cljs.core.async/t_cljs$core$async4568");
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async4568.
 */
cljs.core.async.__GT_t_cljs$core$async4568 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function cljs$core$async$mix_$___GT_t_cljs$core$async4568(out__$1,cs__$1,solo_modes__$1,attrs__$1,solo_mode__$1,change__$1,changed__$1,pick__$1,calc_state__$1,meta4569){
return (new cljs.core.async.t_cljs$core$async4568(out__$1,cs__$1,solo_modes__$1,attrs__$1,solo_mode__$1,change__$1,changed__$1,pick__$1,calc_state__$1,meta4569));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

}

return (new cljs.core.async.t_cljs$core$async4568(out,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__3673__auto___4732 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___4732,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___4732,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (state_4672){
var state_val_4673 = (state_4672[(1)]);
if((state_val_4673 === (7))){
var inst_4587 = (state_4672[(2)]);
var state_4672__$1 = state_4672;
var statearr_4674_4733 = state_4672__$1;
(statearr_4674_4733[(2)] = inst_4587);

(statearr_4674_4733[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (20))){
var inst_4599 = (state_4672[(7)]);
var state_4672__$1 = state_4672;
var statearr_4675_4734 = state_4672__$1;
(statearr_4675_4734[(2)] = inst_4599);

(statearr_4675_4734[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (27))){
var state_4672__$1 = state_4672;
var statearr_4676_4735 = state_4672__$1;
(statearr_4676_4735[(2)] = null);

(statearr_4676_4735[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (1))){
var inst_4574 = (state_4672[(8)]);
var inst_4574__$1 = calc_state.call(null);
var inst_4576 = (inst_4574__$1 == null);
var inst_4577 = cljs.core.not.call(null,inst_4576);
var state_4672__$1 = (function (){var statearr_4677 = state_4672;
(statearr_4677[(8)] = inst_4574__$1);

return statearr_4677;
})();
if(inst_4577){
var statearr_4678_4736 = state_4672__$1;
(statearr_4678_4736[(1)] = (2));

} else {
var statearr_4679_4737 = state_4672__$1;
(statearr_4679_4737[(1)] = (3));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (24))){
var inst_4632 = (state_4672[(9)]);
var inst_4623 = (state_4672[(10)]);
var inst_4646 = (state_4672[(11)]);
var inst_4646__$1 = inst_4623.call(null,inst_4632);
var state_4672__$1 = (function (){var statearr_4680 = state_4672;
(statearr_4680[(11)] = inst_4646__$1);

return statearr_4680;
})();
if(cljs.core.truth_(inst_4646__$1)){
var statearr_4681_4738 = state_4672__$1;
(statearr_4681_4738[(1)] = (29));

} else {
var statearr_4682_4739 = state_4672__$1;
(statearr_4682_4739[(1)] = (30));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (4))){
var inst_4590 = (state_4672[(2)]);
var state_4672__$1 = state_4672;
if(cljs.core.truth_(inst_4590)){
var statearr_4683_4740 = state_4672__$1;
(statearr_4683_4740[(1)] = (8));

} else {
var statearr_4684_4741 = state_4672__$1;
(statearr_4684_4741[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (15))){
var inst_4617 = (state_4672[(2)]);
var state_4672__$1 = state_4672;
if(cljs.core.truth_(inst_4617)){
var statearr_4685_4742 = state_4672__$1;
(statearr_4685_4742[(1)] = (19));

} else {
var statearr_4686_4743 = state_4672__$1;
(statearr_4686_4743[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (21))){
var inst_4622 = (state_4672[(12)]);
var inst_4622__$1 = (state_4672[(2)]);
var inst_4623 = cljs.core.get.call(null,inst_4622__$1,new cljs.core.Keyword(null,"solos","solos",1441458643));
var inst_4624 = cljs.core.get.call(null,inst_4622__$1,new cljs.core.Keyword(null,"mutes","mutes",1068806309));
var inst_4625 = cljs.core.get.call(null,inst_4622__$1,new cljs.core.Keyword(null,"reads","reads",-1215067361));
var state_4672__$1 = (function (){var statearr_4687 = state_4672;
(statearr_4687[(13)] = inst_4624);

(statearr_4687[(12)] = inst_4622__$1);

(statearr_4687[(10)] = inst_4623);

return statearr_4687;
})();
return cljs.core.async.ioc_alts_BANG_.call(null,state_4672__$1,(22),inst_4625);
} else {
if((state_val_4673 === (31))){
var inst_4654 = (state_4672[(2)]);
var state_4672__$1 = state_4672;
if(cljs.core.truth_(inst_4654)){
var statearr_4688_4744 = state_4672__$1;
(statearr_4688_4744[(1)] = (32));

} else {
var statearr_4689_4745 = state_4672__$1;
(statearr_4689_4745[(1)] = (33));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (32))){
var inst_4631 = (state_4672[(14)]);
var state_4672__$1 = state_4672;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_4672__$1,(35),out,inst_4631);
} else {
if((state_val_4673 === (33))){
var inst_4622 = (state_4672[(12)]);
var inst_4599 = inst_4622;
var state_4672__$1 = (function (){var statearr_4690 = state_4672;
(statearr_4690[(7)] = inst_4599);

return statearr_4690;
})();
var statearr_4691_4746 = state_4672__$1;
(statearr_4691_4746[(2)] = null);

(statearr_4691_4746[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (13))){
var inst_4599 = (state_4672[(7)]);
var inst_4606 = inst_4599.cljs$lang$protocol_mask$partition0$;
var inst_4607 = (inst_4606 & (64));
var inst_4608 = inst_4599.cljs$core$ISeq$;
var inst_4609 = (cljs.core.PROTOCOL_SENTINEL === inst_4608);
var inst_4610 = ((inst_4607) || (inst_4609));
var state_4672__$1 = state_4672;
if(cljs.core.truth_(inst_4610)){
var statearr_4692_4747 = state_4672__$1;
(statearr_4692_4747[(1)] = (16));

} else {
var statearr_4693_4748 = state_4672__$1;
(statearr_4693_4748[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (22))){
var inst_4632 = (state_4672[(9)]);
var inst_4631 = (state_4672[(14)]);
var inst_4630 = (state_4672[(2)]);
var inst_4631__$1 = cljs.core.nth.call(null,inst_4630,(0),null);
var inst_4632__$1 = cljs.core.nth.call(null,inst_4630,(1),null);
var inst_4633 = (inst_4631__$1 == null);
var inst_4634 = cljs.core._EQ_.call(null,inst_4632__$1,change);
var inst_4635 = ((inst_4633) || (inst_4634));
var state_4672__$1 = (function (){var statearr_4694 = state_4672;
(statearr_4694[(9)] = inst_4632__$1);

(statearr_4694[(14)] = inst_4631__$1);

return statearr_4694;
})();
if(cljs.core.truth_(inst_4635)){
var statearr_4695_4749 = state_4672__$1;
(statearr_4695_4749[(1)] = (23));

} else {
var statearr_4696_4750 = state_4672__$1;
(statearr_4696_4750[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (36))){
var inst_4622 = (state_4672[(12)]);
var inst_4599 = inst_4622;
var state_4672__$1 = (function (){var statearr_4697 = state_4672;
(statearr_4697[(7)] = inst_4599);

return statearr_4697;
})();
var statearr_4698_4751 = state_4672__$1;
(statearr_4698_4751[(2)] = null);

(statearr_4698_4751[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (29))){
var inst_4646 = (state_4672[(11)]);
var state_4672__$1 = state_4672;
var statearr_4699_4752 = state_4672__$1;
(statearr_4699_4752[(2)] = inst_4646);

(statearr_4699_4752[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (6))){
var state_4672__$1 = state_4672;
var statearr_4700_4753 = state_4672__$1;
(statearr_4700_4753[(2)] = false);

(statearr_4700_4753[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (28))){
var inst_4642 = (state_4672[(2)]);
var inst_4643 = calc_state.call(null);
var inst_4599 = inst_4643;
var state_4672__$1 = (function (){var statearr_4701 = state_4672;
(statearr_4701[(15)] = inst_4642);

(statearr_4701[(7)] = inst_4599);

return statearr_4701;
})();
var statearr_4702_4754 = state_4672__$1;
(statearr_4702_4754[(2)] = null);

(statearr_4702_4754[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (25))){
var inst_4668 = (state_4672[(2)]);
var state_4672__$1 = state_4672;
var statearr_4703_4755 = state_4672__$1;
(statearr_4703_4755[(2)] = inst_4668);

(statearr_4703_4755[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (34))){
var inst_4666 = (state_4672[(2)]);
var state_4672__$1 = state_4672;
var statearr_4704_4756 = state_4672__$1;
(statearr_4704_4756[(2)] = inst_4666);

(statearr_4704_4756[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (17))){
var state_4672__$1 = state_4672;
var statearr_4705_4757 = state_4672__$1;
(statearr_4705_4757[(2)] = false);

(statearr_4705_4757[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (3))){
var state_4672__$1 = state_4672;
var statearr_4706_4758 = state_4672__$1;
(statearr_4706_4758[(2)] = false);

(statearr_4706_4758[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (12))){
var inst_4670 = (state_4672[(2)]);
var state_4672__$1 = state_4672;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_4672__$1,inst_4670);
} else {
if((state_val_4673 === (2))){
var inst_4574 = (state_4672[(8)]);
var inst_4579 = inst_4574.cljs$lang$protocol_mask$partition0$;
var inst_4580 = (inst_4579 & (64));
var inst_4581 = inst_4574.cljs$core$ISeq$;
var inst_4582 = (cljs.core.PROTOCOL_SENTINEL === inst_4581);
var inst_4583 = ((inst_4580) || (inst_4582));
var state_4672__$1 = state_4672;
if(cljs.core.truth_(inst_4583)){
var statearr_4707_4759 = state_4672__$1;
(statearr_4707_4759[(1)] = (5));

} else {
var statearr_4708_4760 = state_4672__$1;
(statearr_4708_4760[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (23))){
var inst_4631 = (state_4672[(14)]);
var inst_4637 = (inst_4631 == null);
var state_4672__$1 = state_4672;
if(cljs.core.truth_(inst_4637)){
var statearr_4709_4761 = state_4672__$1;
(statearr_4709_4761[(1)] = (26));

} else {
var statearr_4710_4762 = state_4672__$1;
(statearr_4710_4762[(1)] = (27));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (35))){
var inst_4657 = (state_4672[(2)]);
var state_4672__$1 = state_4672;
if(cljs.core.truth_(inst_4657)){
var statearr_4711_4763 = state_4672__$1;
(statearr_4711_4763[(1)] = (36));

} else {
var statearr_4712_4764 = state_4672__$1;
(statearr_4712_4764[(1)] = (37));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (19))){
var inst_4599 = (state_4672[(7)]);
var inst_4619 = cljs.core.apply.call(null,cljs.core.hash_map,inst_4599);
var state_4672__$1 = state_4672;
var statearr_4713_4765 = state_4672__$1;
(statearr_4713_4765[(2)] = inst_4619);

(statearr_4713_4765[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (11))){
var inst_4599 = (state_4672[(7)]);
var inst_4603 = (inst_4599 == null);
var inst_4604 = cljs.core.not.call(null,inst_4603);
var state_4672__$1 = state_4672;
if(inst_4604){
var statearr_4714_4766 = state_4672__$1;
(statearr_4714_4766[(1)] = (13));

} else {
var statearr_4715_4767 = state_4672__$1;
(statearr_4715_4767[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (9))){
var inst_4574 = (state_4672[(8)]);
var state_4672__$1 = state_4672;
var statearr_4716_4768 = state_4672__$1;
(statearr_4716_4768[(2)] = inst_4574);

(statearr_4716_4768[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (5))){
var state_4672__$1 = state_4672;
var statearr_4717_4769 = state_4672__$1;
(statearr_4717_4769[(2)] = true);

(statearr_4717_4769[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (14))){
var state_4672__$1 = state_4672;
var statearr_4718_4770 = state_4672__$1;
(statearr_4718_4770[(2)] = false);

(statearr_4718_4770[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (26))){
var inst_4632 = (state_4672[(9)]);
var inst_4639 = cljs.core.swap_BANG_.call(null,cs,cljs.core.dissoc,inst_4632);
var state_4672__$1 = state_4672;
var statearr_4719_4771 = state_4672__$1;
(statearr_4719_4771[(2)] = inst_4639);

(statearr_4719_4771[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (16))){
var state_4672__$1 = state_4672;
var statearr_4720_4772 = state_4672__$1;
(statearr_4720_4772[(2)] = true);

(statearr_4720_4772[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (38))){
var inst_4662 = (state_4672[(2)]);
var state_4672__$1 = state_4672;
var statearr_4721_4773 = state_4672__$1;
(statearr_4721_4773[(2)] = inst_4662);

(statearr_4721_4773[(1)] = (34));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (30))){
var inst_4632 = (state_4672[(9)]);
var inst_4624 = (state_4672[(13)]);
var inst_4623 = (state_4672[(10)]);
var inst_4649 = cljs.core.empty_QMARK_.call(null,inst_4623);
var inst_4650 = inst_4624.call(null,inst_4632);
var inst_4651 = cljs.core.not.call(null,inst_4650);
var inst_4652 = ((inst_4649) && (inst_4651));
var state_4672__$1 = state_4672;
var statearr_4722_4774 = state_4672__$1;
(statearr_4722_4774[(2)] = inst_4652);

(statearr_4722_4774[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (10))){
var inst_4574 = (state_4672[(8)]);
var inst_4595 = (state_4672[(2)]);
var inst_4596 = cljs.core.get.call(null,inst_4595,new cljs.core.Keyword(null,"solos","solos",1441458643));
var inst_4597 = cljs.core.get.call(null,inst_4595,new cljs.core.Keyword(null,"mutes","mutes",1068806309));
var inst_4598 = cljs.core.get.call(null,inst_4595,new cljs.core.Keyword(null,"reads","reads",-1215067361));
var inst_4599 = inst_4574;
var state_4672__$1 = (function (){var statearr_4723 = state_4672;
(statearr_4723[(16)] = inst_4598);

(statearr_4723[(17)] = inst_4597);

(statearr_4723[(7)] = inst_4599);

(statearr_4723[(18)] = inst_4596);

return statearr_4723;
})();
var statearr_4724_4775 = state_4672__$1;
(statearr_4724_4775[(2)] = null);

(statearr_4724_4775[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (18))){
var inst_4614 = (state_4672[(2)]);
var state_4672__$1 = state_4672;
var statearr_4725_4776 = state_4672__$1;
(statearr_4725_4776[(2)] = inst_4614);

(statearr_4725_4776[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (37))){
var state_4672__$1 = state_4672;
var statearr_4726_4777 = state_4672__$1;
(statearr_4726_4777[(2)] = null);

(statearr_4726_4777[(1)] = (38));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4673 === (8))){
var inst_4574 = (state_4672[(8)]);
var inst_4592 = cljs.core.apply.call(null,cljs.core.hash_map,inst_4574);
var state_4672__$1 = state_4672;
var statearr_4727_4778 = state_4672__$1;
(statearr_4727_4778[(2)] = inst_4592);

(statearr_4727_4778[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___4732,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
;
return ((function (switch__3583__auto__,c__3673__auto___4732,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function() {
var cljs$core$async$mix_$_state_machine__3584__auto__ = null;
var cljs$core$async$mix_$_state_machine__3584__auto____0 = (function (){
var statearr_4728 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_4728[(0)] = cljs$core$async$mix_$_state_machine__3584__auto__);

(statearr_4728[(1)] = (1));

return statearr_4728;
});
var cljs$core$async$mix_$_state_machine__3584__auto____1 = (function (state_4672){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_4672);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e4729){if((e4729 instanceof Object)){
var ex__3587__auto__ = e4729;
var statearr_4730_4779 = state_4672;
(statearr_4730_4779[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_4672);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e4729;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4780 = state_4672;
state_4672 = G__4780;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__3584__auto__ = function(state_4672){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__3584__auto____1.call(this,state_4672);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$mix_$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__3584__auto____0;
cljs$core$async$mix_$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__3584__auto____1;
return cljs$core$async$mix_$_state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___4732,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
})();
var state__3675__auto__ = (function (){var statearr_4731 = f__3674__auto__.call(null);
(statearr_4731[(6)] = c__3673__auto___4732);

return statearr_4731;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___4732,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
);


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_.call(null,mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_.call(null,mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_.call(null,mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_.call(null,mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_.call(null,mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if(((!((p == null))) && (!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null))))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__4211__auto__ = (((p == null))?null:p);
var m__4212__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,p,v,ch,close_QMARK_);
} else {
var m__4212__auto____$1 = (cljs.core.async.sub_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,p,v,ch,close_QMARK_);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if(((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null))))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__4211__auto__ = (((p == null))?null:p);
var m__4212__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,p,v,ch);
} else {
var m__4212__auto____$1 = (cljs.core.async.unsub_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,p,v,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var G__4782 = arguments.length;
switch (G__4782) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if(((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__4211__auto__ = (((p == null))?null:p);
var m__4212__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,p);
} else {
var m__4212__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,p);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if(((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__4211__auto__ = (((p == null))?null:p);
var m__4212__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4211__auto__)]);
if(!((m__4212__auto__ == null))){
return m__4212__auto__.call(null,p,v);
} else {
var m__4212__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if(!((m__4212__auto____$1 == null))){
return m__4212__auto____$1.call(null,p,v);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2;


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var G__4786 = arguments.length;
switch (G__4786) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.call(null,ch,topic_fn,cljs.core.constantly.call(null,null));
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var ensure_mult = ((function (mults){
return (function (topic){
var or__3922__auto__ = cljs.core.get.call(null,cljs.core.deref.call(null,mults),topic);
if(cljs.core.truth_(or__3922__auto__)){
return or__3922__auto__;
} else {
return cljs.core.get.call(null,cljs.core.swap_BANG_.call(null,mults,((function (or__3922__auto__,mults){
return (function (p1__4784_SHARP_){
if(cljs.core.truth_(p1__4784_SHARP_.call(null,topic))){
return p1__4784_SHARP_;
} else {
return cljs.core.assoc.call(null,p1__4784_SHARP_,topic,cljs.core.async.mult.call(null,cljs.core.async.chan.call(null,buf_fn.call(null,topic))));
}
});})(or__3922__auto__,mults))
),topic);
}
});})(mults))
;
var p = (function (){
if(typeof cljs.core.async.t_cljs$core$async4787 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async4787 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta4788){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta4788 = meta4788;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async4787.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (mults,ensure_mult){
return (function (_4789,meta4788__$1){
var self__ = this;
var _4789__$1 = this;
return (new cljs.core.async.t_cljs$core$async4787(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta4788__$1));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async4787.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (mults,ensure_mult){
return (function (_4789){
var self__ = this;
var _4789__$1 = this;
return self__.meta4788;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async4787.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async4787.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async4787.prototype.cljs$core$async$Pub$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async4787.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = self__.ensure_mult.call(null,topic);
return cljs.core.async.tap.call(null,m,ch__$1,close_QMARK_);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async4787.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__5457__auto__ = cljs.core.get.call(null,cljs.core.deref.call(null,self__.mults),topic);
if(cljs.core.truth_(temp__5457__auto__)){
var m = temp__5457__auto__;
return cljs.core.async.untap.call(null,m,ch__$1);
} else {
return null;
}
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async4787.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.reset_BANG_.call(null,self__.mults,cljs.core.PersistentArrayMap.EMPTY);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async4787.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = ((function (mults,ensure_mult){
return (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.call(null,self__.mults,cljs.core.dissoc,topic);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async4787.getBasis = ((function (mults,ensure_mult){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"topic-fn","topic-fn",-862449736,null),new cljs.core.Symbol(null,"buf-fn","buf-fn",-1200281591,null),new cljs.core.Symbol(null,"mults","mults",-461114485,null),new cljs.core.Symbol(null,"ensure-mult","ensure-mult",1796584816,null),new cljs.core.Symbol(null,"meta4788","meta4788",-1272126524,null)], null);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async4787.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async4787.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async4787";

cljs.core.async.t_cljs$core$async4787.cljs$lang$ctorPrWriter = ((function (mults,ensure_mult){
return (function (this__4161__auto__,writer__4162__auto__,opt__4163__auto__){
return cljs.core._write.call(null,writer__4162__auto__,"cljs.core.async/t_cljs$core$async4787");
});})(mults,ensure_mult))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async4787.
 */
cljs.core.async.__GT_t_cljs$core$async4787 = ((function (mults,ensure_mult){
return (function cljs$core$async$__GT_t_cljs$core$async4787(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta4788){
return (new cljs.core.async.t_cljs$core$async4787(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta4788));
});})(mults,ensure_mult))
;

}

return (new cljs.core.async.t_cljs$core$async4787(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__3673__auto___4907 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___4907,mults,ensure_mult,p){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___4907,mults,ensure_mult,p){
return (function (state_4861){
var state_val_4862 = (state_4861[(1)]);
if((state_val_4862 === (7))){
var inst_4857 = (state_4861[(2)]);
var state_4861__$1 = state_4861;
var statearr_4863_4908 = state_4861__$1;
(statearr_4863_4908[(2)] = inst_4857);

(statearr_4863_4908[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (20))){
var state_4861__$1 = state_4861;
var statearr_4864_4909 = state_4861__$1;
(statearr_4864_4909[(2)] = null);

(statearr_4864_4909[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (1))){
var state_4861__$1 = state_4861;
var statearr_4865_4910 = state_4861__$1;
(statearr_4865_4910[(2)] = null);

(statearr_4865_4910[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (24))){
var inst_4840 = (state_4861[(7)]);
var inst_4849 = cljs.core.swap_BANG_.call(null,mults,cljs.core.dissoc,inst_4840);
var state_4861__$1 = state_4861;
var statearr_4866_4911 = state_4861__$1;
(statearr_4866_4911[(2)] = inst_4849);

(statearr_4866_4911[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (4))){
var inst_4792 = (state_4861[(8)]);
var inst_4792__$1 = (state_4861[(2)]);
var inst_4793 = (inst_4792__$1 == null);
var state_4861__$1 = (function (){var statearr_4867 = state_4861;
(statearr_4867[(8)] = inst_4792__$1);

return statearr_4867;
})();
if(cljs.core.truth_(inst_4793)){
var statearr_4868_4912 = state_4861__$1;
(statearr_4868_4912[(1)] = (5));

} else {
var statearr_4869_4913 = state_4861__$1;
(statearr_4869_4913[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (15))){
var inst_4834 = (state_4861[(2)]);
var state_4861__$1 = state_4861;
var statearr_4870_4914 = state_4861__$1;
(statearr_4870_4914[(2)] = inst_4834);

(statearr_4870_4914[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (21))){
var inst_4854 = (state_4861[(2)]);
var state_4861__$1 = (function (){var statearr_4871 = state_4861;
(statearr_4871[(9)] = inst_4854);

return statearr_4871;
})();
var statearr_4872_4915 = state_4861__$1;
(statearr_4872_4915[(2)] = null);

(statearr_4872_4915[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (13))){
var inst_4816 = (state_4861[(10)]);
var inst_4818 = cljs.core.chunked_seq_QMARK_.call(null,inst_4816);
var state_4861__$1 = state_4861;
if(inst_4818){
var statearr_4873_4916 = state_4861__$1;
(statearr_4873_4916[(1)] = (16));

} else {
var statearr_4874_4917 = state_4861__$1;
(statearr_4874_4917[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (22))){
var inst_4846 = (state_4861[(2)]);
var state_4861__$1 = state_4861;
if(cljs.core.truth_(inst_4846)){
var statearr_4875_4918 = state_4861__$1;
(statearr_4875_4918[(1)] = (23));

} else {
var statearr_4876_4919 = state_4861__$1;
(statearr_4876_4919[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (6))){
var inst_4792 = (state_4861[(8)]);
var inst_4840 = (state_4861[(7)]);
var inst_4842 = (state_4861[(11)]);
var inst_4840__$1 = topic_fn.call(null,inst_4792);
var inst_4841 = cljs.core.deref.call(null,mults);
var inst_4842__$1 = cljs.core.get.call(null,inst_4841,inst_4840__$1);
var state_4861__$1 = (function (){var statearr_4877 = state_4861;
(statearr_4877[(7)] = inst_4840__$1);

(statearr_4877[(11)] = inst_4842__$1);

return statearr_4877;
})();
if(cljs.core.truth_(inst_4842__$1)){
var statearr_4878_4920 = state_4861__$1;
(statearr_4878_4920[(1)] = (19));

} else {
var statearr_4879_4921 = state_4861__$1;
(statearr_4879_4921[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (25))){
var inst_4851 = (state_4861[(2)]);
var state_4861__$1 = state_4861;
var statearr_4880_4922 = state_4861__$1;
(statearr_4880_4922[(2)] = inst_4851);

(statearr_4880_4922[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (17))){
var inst_4816 = (state_4861[(10)]);
var inst_4825 = cljs.core.first.call(null,inst_4816);
var inst_4826 = cljs.core.async.muxch_STAR_.call(null,inst_4825);
var inst_4827 = cljs.core.async.close_BANG_.call(null,inst_4826);
var inst_4828 = cljs.core.next.call(null,inst_4816);
var inst_4802 = inst_4828;
var inst_4803 = null;
var inst_4804 = (0);
var inst_4805 = (0);
var state_4861__$1 = (function (){var statearr_4881 = state_4861;
(statearr_4881[(12)] = inst_4805);

(statearr_4881[(13)] = inst_4827);

(statearr_4881[(14)] = inst_4804);

(statearr_4881[(15)] = inst_4802);

(statearr_4881[(16)] = inst_4803);

return statearr_4881;
})();
var statearr_4882_4923 = state_4861__$1;
(statearr_4882_4923[(2)] = null);

(statearr_4882_4923[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (3))){
var inst_4859 = (state_4861[(2)]);
var state_4861__$1 = state_4861;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_4861__$1,inst_4859);
} else {
if((state_val_4862 === (12))){
var inst_4836 = (state_4861[(2)]);
var state_4861__$1 = state_4861;
var statearr_4883_4924 = state_4861__$1;
(statearr_4883_4924[(2)] = inst_4836);

(statearr_4883_4924[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (2))){
var state_4861__$1 = state_4861;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_4861__$1,(4),ch);
} else {
if((state_val_4862 === (23))){
var state_4861__$1 = state_4861;
var statearr_4884_4925 = state_4861__$1;
(statearr_4884_4925[(2)] = null);

(statearr_4884_4925[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (19))){
var inst_4792 = (state_4861[(8)]);
var inst_4842 = (state_4861[(11)]);
var inst_4844 = cljs.core.async.muxch_STAR_.call(null,inst_4842);
var state_4861__$1 = state_4861;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_4861__$1,(22),inst_4844,inst_4792);
} else {
if((state_val_4862 === (11))){
var inst_4802 = (state_4861[(15)]);
var inst_4816 = (state_4861[(10)]);
var inst_4816__$1 = cljs.core.seq.call(null,inst_4802);
var state_4861__$1 = (function (){var statearr_4885 = state_4861;
(statearr_4885[(10)] = inst_4816__$1);

return statearr_4885;
})();
if(inst_4816__$1){
var statearr_4886_4926 = state_4861__$1;
(statearr_4886_4926[(1)] = (13));

} else {
var statearr_4887_4927 = state_4861__$1;
(statearr_4887_4927[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (9))){
var inst_4838 = (state_4861[(2)]);
var state_4861__$1 = state_4861;
var statearr_4888_4928 = state_4861__$1;
(statearr_4888_4928[(2)] = inst_4838);

(statearr_4888_4928[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (5))){
var inst_4799 = cljs.core.deref.call(null,mults);
var inst_4800 = cljs.core.vals.call(null,inst_4799);
var inst_4801 = cljs.core.seq.call(null,inst_4800);
var inst_4802 = inst_4801;
var inst_4803 = null;
var inst_4804 = (0);
var inst_4805 = (0);
var state_4861__$1 = (function (){var statearr_4889 = state_4861;
(statearr_4889[(12)] = inst_4805);

(statearr_4889[(14)] = inst_4804);

(statearr_4889[(15)] = inst_4802);

(statearr_4889[(16)] = inst_4803);

return statearr_4889;
})();
var statearr_4890_4929 = state_4861__$1;
(statearr_4890_4929[(2)] = null);

(statearr_4890_4929[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (14))){
var state_4861__$1 = state_4861;
var statearr_4894_4930 = state_4861__$1;
(statearr_4894_4930[(2)] = null);

(statearr_4894_4930[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (16))){
var inst_4816 = (state_4861[(10)]);
var inst_4820 = cljs.core.chunk_first.call(null,inst_4816);
var inst_4821 = cljs.core.chunk_rest.call(null,inst_4816);
var inst_4822 = cljs.core.count.call(null,inst_4820);
var inst_4802 = inst_4821;
var inst_4803 = inst_4820;
var inst_4804 = inst_4822;
var inst_4805 = (0);
var state_4861__$1 = (function (){var statearr_4895 = state_4861;
(statearr_4895[(12)] = inst_4805);

(statearr_4895[(14)] = inst_4804);

(statearr_4895[(15)] = inst_4802);

(statearr_4895[(16)] = inst_4803);

return statearr_4895;
})();
var statearr_4896_4931 = state_4861__$1;
(statearr_4896_4931[(2)] = null);

(statearr_4896_4931[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (10))){
var inst_4805 = (state_4861[(12)]);
var inst_4804 = (state_4861[(14)]);
var inst_4802 = (state_4861[(15)]);
var inst_4803 = (state_4861[(16)]);
var inst_4810 = cljs.core._nth.call(null,inst_4803,inst_4805);
var inst_4811 = cljs.core.async.muxch_STAR_.call(null,inst_4810);
var inst_4812 = cljs.core.async.close_BANG_.call(null,inst_4811);
var inst_4813 = (inst_4805 + (1));
var tmp4891 = inst_4804;
var tmp4892 = inst_4802;
var tmp4893 = inst_4803;
var inst_4802__$1 = tmp4892;
var inst_4803__$1 = tmp4893;
var inst_4804__$1 = tmp4891;
var inst_4805__$1 = inst_4813;
var state_4861__$1 = (function (){var statearr_4897 = state_4861;
(statearr_4897[(12)] = inst_4805__$1);

(statearr_4897[(17)] = inst_4812);

(statearr_4897[(14)] = inst_4804__$1);

(statearr_4897[(15)] = inst_4802__$1);

(statearr_4897[(16)] = inst_4803__$1);

return statearr_4897;
})();
var statearr_4898_4932 = state_4861__$1;
(statearr_4898_4932[(2)] = null);

(statearr_4898_4932[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (18))){
var inst_4831 = (state_4861[(2)]);
var state_4861__$1 = state_4861;
var statearr_4899_4933 = state_4861__$1;
(statearr_4899_4933[(2)] = inst_4831);

(statearr_4899_4933[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4862 === (8))){
var inst_4805 = (state_4861[(12)]);
var inst_4804 = (state_4861[(14)]);
var inst_4807 = (inst_4805 < inst_4804);
var inst_4808 = inst_4807;
var state_4861__$1 = state_4861;
if(cljs.core.truth_(inst_4808)){
var statearr_4900_4934 = state_4861__$1;
(statearr_4900_4934[(1)] = (10));

} else {
var statearr_4901_4935 = state_4861__$1;
(statearr_4901_4935[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___4907,mults,ensure_mult,p))
;
return ((function (switch__3583__auto__,c__3673__auto___4907,mults,ensure_mult,p){
return (function() {
var cljs$core$async$state_machine__3584__auto__ = null;
var cljs$core$async$state_machine__3584__auto____0 = (function (){
var statearr_4902 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_4902[(0)] = cljs$core$async$state_machine__3584__auto__);

(statearr_4902[(1)] = (1));

return statearr_4902;
});
var cljs$core$async$state_machine__3584__auto____1 = (function (state_4861){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_4861);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e4903){if((e4903 instanceof Object)){
var ex__3587__auto__ = e4903;
var statearr_4904_4936 = state_4861;
(statearr_4904_4936[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_4861);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e4903;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__4937 = state_4861;
state_4861 = G__4937;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$state_machine__3584__auto__ = function(state_4861){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__3584__auto____1.call(this,state_4861);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__3584__auto____0;
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__3584__auto____1;
return cljs$core$async$state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___4907,mults,ensure_mult,p))
})();
var state__3675__auto__ = (function (){var statearr_4905 = f__3674__auto__.call(null);
(statearr_4905[(6)] = c__3673__auto___4907);

return statearr_4905;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___4907,mults,ensure_mult,p))
);


return p;
});

cljs.core.async.pub.cljs$lang$maxFixedArity = 3;

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var G__4939 = arguments.length;
switch (G__4939) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.call(null,p,topic,ch,true);
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_.call(null,p,topic,ch,close_QMARK_);
});

cljs.core.async.sub.cljs$lang$maxFixedArity = 4;

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_.call(null,p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var G__4942 = arguments.length;
switch (G__4942) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.call(null,p);
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.call(null,p,topic);
});

cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2;

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var G__4945 = arguments.length;
switch (G__4945) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.call(null,f,chs,null);
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec.call(null,chs);
var out = cljs.core.async.chan.call(null,buf_or_n);
var cnt = cljs.core.count.call(null,chs__$1);
var rets = cljs.core.object_array.call(null,cnt);
var dchan = cljs.core.async.chan.call(null,(1));
var dctr = cljs.core.atom.call(null,null);
var done = cljs.core.mapv.call(null,((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (i){
return ((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.call(null,dchan,rets.slice((0)));
} else {
return null;
}
});
;})(chs__$1,out,cnt,rets,dchan,dctr))
});})(chs__$1,out,cnt,rets,dchan,dctr))
,cljs.core.range.call(null,cnt));
var c__3673__auto___5012 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___5012,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___5012,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (state_4984){
var state_val_4985 = (state_4984[(1)]);
if((state_val_4985 === (7))){
var state_4984__$1 = state_4984;
var statearr_4986_5013 = state_4984__$1;
(statearr_4986_5013[(2)] = null);

(statearr_4986_5013[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (1))){
var state_4984__$1 = state_4984;
var statearr_4987_5014 = state_4984__$1;
(statearr_4987_5014[(2)] = null);

(statearr_4987_5014[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (4))){
var inst_4948 = (state_4984[(7)]);
var inst_4950 = (inst_4948 < cnt);
var state_4984__$1 = state_4984;
if(cljs.core.truth_(inst_4950)){
var statearr_4988_5015 = state_4984__$1;
(statearr_4988_5015[(1)] = (6));

} else {
var statearr_4989_5016 = state_4984__$1;
(statearr_4989_5016[(1)] = (7));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (15))){
var inst_4980 = (state_4984[(2)]);
var state_4984__$1 = state_4984;
var statearr_4990_5017 = state_4984__$1;
(statearr_4990_5017[(2)] = inst_4980);

(statearr_4990_5017[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (13))){
var inst_4973 = cljs.core.async.close_BANG_.call(null,out);
var state_4984__$1 = state_4984;
var statearr_4991_5018 = state_4984__$1;
(statearr_4991_5018[(2)] = inst_4973);

(statearr_4991_5018[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (6))){
var state_4984__$1 = state_4984;
var statearr_4992_5019 = state_4984__$1;
(statearr_4992_5019[(2)] = null);

(statearr_4992_5019[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (3))){
var inst_4982 = (state_4984[(2)]);
var state_4984__$1 = state_4984;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_4984__$1,inst_4982);
} else {
if((state_val_4985 === (12))){
var inst_4970 = (state_4984[(8)]);
var inst_4970__$1 = (state_4984[(2)]);
var inst_4971 = cljs.core.some.call(null,cljs.core.nil_QMARK_,inst_4970__$1);
var state_4984__$1 = (function (){var statearr_4993 = state_4984;
(statearr_4993[(8)] = inst_4970__$1);

return statearr_4993;
})();
if(cljs.core.truth_(inst_4971)){
var statearr_4994_5020 = state_4984__$1;
(statearr_4994_5020[(1)] = (13));

} else {
var statearr_4995_5021 = state_4984__$1;
(statearr_4995_5021[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (2))){
var inst_4947 = cljs.core.reset_BANG_.call(null,dctr,cnt);
var inst_4948 = (0);
var state_4984__$1 = (function (){var statearr_4996 = state_4984;
(statearr_4996[(7)] = inst_4948);

(statearr_4996[(9)] = inst_4947);

return statearr_4996;
})();
var statearr_4997_5022 = state_4984__$1;
(statearr_4997_5022[(2)] = null);

(statearr_4997_5022[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (11))){
var inst_4948 = (state_4984[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame.call(null,state_4984,(10),Object,null,(9));
var inst_4957 = chs__$1.call(null,inst_4948);
var inst_4958 = done.call(null,inst_4948);
var inst_4959 = cljs.core.async.take_BANG_.call(null,inst_4957,inst_4958);
var state_4984__$1 = state_4984;
var statearr_4998_5023 = state_4984__$1;
(statearr_4998_5023[(2)] = inst_4959);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_4984__$1);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (9))){
var inst_4948 = (state_4984[(7)]);
var inst_4961 = (state_4984[(2)]);
var inst_4962 = (inst_4948 + (1));
var inst_4948__$1 = inst_4962;
var state_4984__$1 = (function (){var statearr_4999 = state_4984;
(statearr_4999[(7)] = inst_4948__$1);

(statearr_4999[(10)] = inst_4961);

return statearr_4999;
})();
var statearr_5000_5024 = state_4984__$1;
(statearr_5000_5024[(2)] = null);

(statearr_5000_5024[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (5))){
var inst_4968 = (state_4984[(2)]);
var state_4984__$1 = (function (){var statearr_5001 = state_4984;
(statearr_5001[(11)] = inst_4968);

return statearr_5001;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_4984__$1,(12),dchan);
} else {
if((state_val_4985 === (14))){
var inst_4970 = (state_4984[(8)]);
var inst_4975 = cljs.core.apply.call(null,f,inst_4970);
var state_4984__$1 = state_4984;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_4984__$1,(16),out,inst_4975);
} else {
if((state_val_4985 === (16))){
var inst_4977 = (state_4984[(2)]);
var state_4984__$1 = (function (){var statearr_5002 = state_4984;
(statearr_5002[(12)] = inst_4977);

return statearr_5002;
})();
var statearr_5003_5025 = state_4984__$1;
(statearr_5003_5025[(2)] = null);

(statearr_5003_5025[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (10))){
var inst_4952 = (state_4984[(2)]);
var inst_4953 = cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec);
var state_4984__$1 = (function (){var statearr_5004 = state_4984;
(statearr_5004[(13)] = inst_4952);

return statearr_5004;
})();
var statearr_5005_5026 = state_4984__$1;
(statearr_5005_5026[(2)] = inst_4953);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_4984__$1);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_4985 === (8))){
var inst_4966 = (state_4984[(2)]);
var state_4984__$1 = state_4984;
var statearr_5006_5027 = state_4984__$1;
(statearr_5006_5027[(2)] = inst_4966);

(statearr_5006_5027[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___5012,chs__$1,out,cnt,rets,dchan,dctr,done))
;
return ((function (switch__3583__auto__,c__3673__auto___5012,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function() {
var cljs$core$async$state_machine__3584__auto__ = null;
var cljs$core$async$state_machine__3584__auto____0 = (function (){
var statearr_5007 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_5007[(0)] = cljs$core$async$state_machine__3584__auto__);

(statearr_5007[(1)] = (1));

return statearr_5007;
});
var cljs$core$async$state_machine__3584__auto____1 = (function (state_4984){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_4984);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e5008){if((e5008 instanceof Object)){
var ex__3587__auto__ = e5008;
var statearr_5009_5028 = state_4984;
(statearr_5009_5028[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_4984);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e5008;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__5029 = state_4984;
state_4984 = G__5029;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$state_machine__3584__auto__ = function(state_4984){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__3584__auto____1.call(this,state_4984);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__3584__auto____0;
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__3584__auto____1;
return cljs$core$async$state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___5012,chs__$1,out,cnt,rets,dchan,dctr,done))
})();
var state__3675__auto__ = (function (){var statearr_5010 = f__3674__auto__.call(null);
(statearr_5010[(6)] = c__3673__auto___5012);

return statearr_5010;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___5012,chs__$1,out,cnt,rets,dchan,dctr,done))
);


return out;
});

cljs.core.async.map.cljs$lang$maxFixedArity = 3;

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var G__5032 = arguments.length;
switch (G__5032) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.call(null,chs,null);
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__3673__auto___5086 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___5086,out){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___5086,out){
return (function (state_5064){
var state_val_5065 = (state_5064[(1)]);
if((state_val_5065 === (7))){
var inst_5043 = (state_5064[(7)]);
var inst_5044 = (state_5064[(8)]);
var inst_5043__$1 = (state_5064[(2)]);
var inst_5044__$1 = cljs.core.nth.call(null,inst_5043__$1,(0),null);
var inst_5045 = cljs.core.nth.call(null,inst_5043__$1,(1),null);
var inst_5046 = (inst_5044__$1 == null);
var state_5064__$1 = (function (){var statearr_5066 = state_5064;
(statearr_5066[(7)] = inst_5043__$1);

(statearr_5066[(8)] = inst_5044__$1);

(statearr_5066[(9)] = inst_5045);

return statearr_5066;
})();
if(cljs.core.truth_(inst_5046)){
var statearr_5067_5087 = state_5064__$1;
(statearr_5067_5087[(1)] = (8));

} else {
var statearr_5068_5088 = state_5064__$1;
(statearr_5068_5088[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5065 === (1))){
var inst_5033 = cljs.core.vec.call(null,chs);
var inst_5034 = inst_5033;
var state_5064__$1 = (function (){var statearr_5069 = state_5064;
(statearr_5069[(10)] = inst_5034);

return statearr_5069;
})();
var statearr_5070_5089 = state_5064__$1;
(statearr_5070_5089[(2)] = null);

(statearr_5070_5089[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5065 === (4))){
var inst_5034 = (state_5064[(10)]);
var state_5064__$1 = state_5064;
return cljs.core.async.ioc_alts_BANG_.call(null,state_5064__$1,(7),inst_5034);
} else {
if((state_val_5065 === (6))){
var inst_5060 = (state_5064[(2)]);
var state_5064__$1 = state_5064;
var statearr_5071_5090 = state_5064__$1;
(statearr_5071_5090[(2)] = inst_5060);

(statearr_5071_5090[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5065 === (3))){
var inst_5062 = (state_5064[(2)]);
var state_5064__$1 = state_5064;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_5064__$1,inst_5062);
} else {
if((state_val_5065 === (2))){
var inst_5034 = (state_5064[(10)]);
var inst_5036 = cljs.core.count.call(null,inst_5034);
var inst_5037 = (inst_5036 > (0));
var state_5064__$1 = state_5064;
if(cljs.core.truth_(inst_5037)){
var statearr_5073_5091 = state_5064__$1;
(statearr_5073_5091[(1)] = (4));

} else {
var statearr_5074_5092 = state_5064__$1;
(statearr_5074_5092[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5065 === (11))){
var inst_5034 = (state_5064[(10)]);
var inst_5053 = (state_5064[(2)]);
var tmp5072 = inst_5034;
var inst_5034__$1 = tmp5072;
var state_5064__$1 = (function (){var statearr_5075 = state_5064;
(statearr_5075[(10)] = inst_5034__$1);

(statearr_5075[(11)] = inst_5053);

return statearr_5075;
})();
var statearr_5076_5093 = state_5064__$1;
(statearr_5076_5093[(2)] = null);

(statearr_5076_5093[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5065 === (9))){
var inst_5044 = (state_5064[(8)]);
var state_5064__$1 = state_5064;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_5064__$1,(11),out,inst_5044);
} else {
if((state_val_5065 === (5))){
var inst_5058 = cljs.core.async.close_BANG_.call(null,out);
var state_5064__$1 = state_5064;
var statearr_5077_5094 = state_5064__$1;
(statearr_5077_5094[(2)] = inst_5058);

(statearr_5077_5094[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5065 === (10))){
var inst_5056 = (state_5064[(2)]);
var state_5064__$1 = state_5064;
var statearr_5078_5095 = state_5064__$1;
(statearr_5078_5095[(2)] = inst_5056);

(statearr_5078_5095[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5065 === (8))){
var inst_5034 = (state_5064[(10)]);
var inst_5043 = (state_5064[(7)]);
var inst_5044 = (state_5064[(8)]);
var inst_5045 = (state_5064[(9)]);
var inst_5048 = (function (){var cs = inst_5034;
var vec__5039 = inst_5043;
var v = inst_5044;
var c = inst_5045;
return ((function (cs,vec__5039,v,c,inst_5034,inst_5043,inst_5044,inst_5045,state_val_5065,c__3673__auto___5086,out){
return (function (p1__5030_SHARP_){
return cljs.core.not_EQ_.call(null,c,p1__5030_SHARP_);
});
;})(cs,vec__5039,v,c,inst_5034,inst_5043,inst_5044,inst_5045,state_val_5065,c__3673__auto___5086,out))
})();
var inst_5049 = cljs.core.filterv.call(null,inst_5048,inst_5034);
var inst_5034__$1 = inst_5049;
var state_5064__$1 = (function (){var statearr_5079 = state_5064;
(statearr_5079[(10)] = inst_5034__$1);

return statearr_5079;
})();
var statearr_5080_5096 = state_5064__$1;
(statearr_5080_5096[(2)] = null);

(statearr_5080_5096[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___5086,out))
;
return ((function (switch__3583__auto__,c__3673__auto___5086,out){
return (function() {
var cljs$core$async$state_machine__3584__auto__ = null;
var cljs$core$async$state_machine__3584__auto____0 = (function (){
var statearr_5081 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_5081[(0)] = cljs$core$async$state_machine__3584__auto__);

(statearr_5081[(1)] = (1));

return statearr_5081;
});
var cljs$core$async$state_machine__3584__auto____1 = (function (state_5064){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_5064);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e5082){if((e5082 instanceof Object)){
var ex__3587__auto__ = e5082;
var statearr_5083_5097 = state_5064;
(statearr_5083_5097[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_5064);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e5082;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__5098 = state_5064;
state_5064 = G__5098;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$state_machine__3584__auto__ = function(state_5064){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__3584__auto____1.call(this,state_5064);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__3584__auto____0;
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__3584__auto____1;
return cljs$core$async$state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___5086,out))
})();
var state__3675__auto__ = (function (){var statearr_5084 = f__3674__auto__.call(null);
(statearr_5084[(6)] = c__3673__auto___5086);

return statearr_5084;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___5086,out))
);


return out;
});

cljs.core.async.merge.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce.call(null,cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var G__5100 = arguments.length;
switch (G__5100) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.call(null,n,ch,null);
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__3673__auto___5145 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___5145,out){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___5145,out){
return (function (state_5124){
var state_val_5125 = (state_5124[(1)]);
if((state_val_5125 === (7))){
var inst_5106 = (state_5124[(7)]);
var inst_5106__$1 = (state_5124[(2)]);
var inst_5107 = (inst_5106__$1 == null);
var inst_5108 = cljs.core.not.call(null,inst_5107);
var state_5124__$1 = (function (){var statearr_5126 = state_5124;
(statearr_5126[(7)] = inst_5106__$1);

return statearr_5126;
})();
if(inst_5108){
var statearr_5127_5146 = state_5124__$1;
(statearr_5127_5146[(1)] = (8));

} else {
var statearr_5128_5147 = state_5124__$1;
(statearr_5128_5147[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5125 === (1))){
var inst_5101 = (0);
var state_5124__$1 = (function (){var statearr_5129 = state_5124;
(statearr_5129[(8)] = inst_5101);

return statearr_5129;
})();
var statearr_5130_5148 = state_5124__$1;
(statearr_5130_5148[(2)] = null);

(statearr_5130_5148[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5125 === (4))){
var state_5124__$1 = state_5124;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_5124__$1,(7),ch);
} else {
if((state_val_5125 === (6))){
var inst_5119 = (state_5124[(2)]);
var state_5124__$1 = state_5124;
var statearr_5131_5149 = state_5124__$1;
(statearr_5131_5149[(2)] = inst_5119);

(statearr_5131_5149[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5125 === (3))){
var inst_5121 = (state_5124[(2)]);
var inst_5122 = cljs.core.async.close_BANG_.call(null,out);
var state_5124__$1 = (function (){var statearr_5132 = state_5124;
(statearr_5132[(9)] = inst_5121);

return statearr_5132;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_5124__$1,inst_5122);
} else {
if((state_val_5125 === (2))){
var inst_5101 = (state_5124[(8)]);
var inst_5103 = (inst_5101 < n);
var state_5124__$1 = state_5124;
if(cljs.core.truth_(inst_5103)){
var statearr_5133_5150 = state_5124__$1;
(statearr_5133_5150[(1)] = (4));

} else {
var statearr_5134_5151 = state_5124__$1;
(statearr_5134_5151[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5125 === (11))){
var inst_5101 = (state_5124[(8)]);
var inst_5111 = (state_5124[(2)]);
var inst_5112 = (inst_5101 + (1));
var inst_5101__$1 = inst_5112;
var state_5124__$1 = (function (){var statearr_5135 = state_5124;
(statearr_5135[(10)] = inst_5111);

(statearr_5135[(8)] = inst_5101__$1);

return statearr_5135;
})();
var statearr_5136_5152 = state_5124__$1;
(statearr_5136_5152[(2)] = null);

(statearr_5136_5152[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5125 === (9))){
var state_5124__$1 = state_5124;
var statearr_5137_5153 = state_5124__$1;
(statearr_5137_5153[(2)] = null);

(statearr_5137_5153[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5125 === (5))){
var state_5124__$1 = state_5124;
var statearr_5138_5154 = state_5124__$1;
(statearr_5138_5154[(2)] = null);

(statearr_5138_5154[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5125 === (10))){
var inst_5116 = (state_5124[(2)]);
var state_5124__$1 = state_5124;
var statearr_5139_5155 = state_5124__$1;
(statearr_5139_5155[(2)] = inst_5116);

(statearr_5139_5155[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5125 === (8))){
var inst_5106 = (state_5124[(7)]);
var state_5124__$1 = state_5124;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_5124__$1,(11),out,inst_5106);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___5145,out))
;
return ((function (switch__3583__auto__,c__3673__auto___5145,out){
return (function() {
var cljs$core$async$state_machine__3584__auto__ = null;
var cljs$core$async$state_machine__3584__auto____0 = (function (){
var statearr_5140 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_5140[(0)] = cljs$core$async$state_machine__3584__auto__);

(statearr_5140[(1)] = (1));

return statearr_5140;
});
var cljs$core$async$state_machine__3584__auto____1 = (function (state_5124){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_5124);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e5141){if((e5141 instanceof Object)){
var ex__3587__auto__ = e5141;
var statearr_5142_5156 = state_5124;
(statearr_5142_5156[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_5124);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e5141;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__5157 = state_5124;
state_5124 = G__5157;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$state_machine__3584__auto__ = function(state_5124){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__3584__auto____1.call(this,state_5124);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__3584__auto____0;
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__3584__auto____1;
return cljs$core$async$state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___5145,out))
})();
var state__3675__auto__ = (function (){var statearr_5143 = f__3674__auto__.call(null);
(statearr_5143[(6)] = c__3673__auto___5145);

return statearr_5143;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___5145,out))
);


return out;
});

cljs.core.async.take.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if(typeof cljs.core.async.t_cljs$core$async5159 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async5159 = (function (f,ch,meta5160){
this.f = f;
this.ch = ch;
this.meta5160 = meta5160;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async5159.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_5161,meta5160__$1){
var self__ = this;
var _5161__$1 = this;
return (new cljs.core.async.t_cljs$core$async5159(self__.f,self__.ch,meta5160__$1));
});

cljs.core.async.t_cljs$core$async5159.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_5161){
var self__ = this;
var _5161__$1 = this;
return self__.meta5160;
});

cljs.core.async.t_cljs$core$async5159.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async5159.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async5159.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async5159.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async5159.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,(function (){
if(typeof cljs.core.async.t_cljs$core$async5162 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async5162 = (function (f,ch,meta5160,_,fn1,meta5163){
this.f = f;
this.ch = ch;
this.meta5160 = meta5160;
this._ = _;
this.fn1 = fn1;
this.meta5163 = meta5163;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async5162.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (___$1){
return (function (_5164,meta5163__$1){
var self__ = this;
var _5164__$1 = this;
return (new cljs.core.async.t_cljs$core$async5162(self__.f,self__.ch,self__.meta5160,self__._,self__.fn1,meta5163__$1));
});})(___$1))
;

cljs.core.async.t_cljs$core$async5162.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (___$1){
return (function (_5164){
var self__ = this;
var _5164__$1 = this;
return self__.meta5163;
});})(___$1))
;

cljs.core.async.t_cljs$core$async5162.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async5162.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_.call(null,self__.fn1);
});})(___$1))
;

cljs.core.async.t_cljs$core$async5162.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
});})(___$1))
;

cljs.core.async.t_cljs$core$async5162.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit.call(null,self__.fn1);
return ((function (f1,___$2,___$1){
return (function (p1__5158_SHARP_){
return f1.call(null,(((p1__5158_SHARP_ == null))?null:self__.f.call(null,p1__5158_SHARP_)));
});
;})(f1,___$2,___$1))
});})(___$1))
;

cljs.core.async.t_cljs$core$async5162.getBasis = ((function (___$1){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta5160","meta5160",1526085478,null),cljs.core.with_meta(new cljs.core.Symbol(null,"_","_",-1201019570,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core.async","t_cljs$core$async5159","cljs.core.async/t_cljs$core$async5159",471815617,null)], null)),new cljs.core.Symbol(null,"fn1","fn1",895834444,null),new cljs.core.Symbol(null,"meta5163","meta5163",-992331921,null)], null);
});})(___$1))
;

cljs.core.async.t_cljs$core$async5162.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async5162.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async5162";

cljs.core.async.t_cljs$core$async5162.cljs$lang$ctorPrWriter = ((function (___$1){
return (function (this__4161__auto__,writer__4162__auto__,opt__4163__auto__){
return cljs.core._write.call(null,writer__4162__auto__,"cljs.core.async/t_cljs$core$async5162");
});})(___$1))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async5162.
 */
cljs.core.async.__GT_t_cljs$core$async5162 = ((function (___$1){
return (function cljs$core$async$map_LT__$___GT_t_cljs$core$async5162(f__$1,ch__$1,meta5160__$1,___$2,fn1__$1,meta5163){
return (new cljs.core.async.t_cljs$core$async5162(f__$1,ch__$1,meta5160__$1,___$2,fn1__$1,meta5163));
});})(___$1))
;

}

return (new cljs.core.async.t_cljs$core$async5162(self__.f,self__.ch,self__.meta5160,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__3911__auto__ = ret;
if(cljs.core.truth_(and__3911__auto__)){
return !((cljs.core.deref.call(null,ret) == null));
} else {
return and__3911__auto__;
}
})())){
return cljs.core.async.impl.channels.box.call(null,self__.f.call(null,cljs.core.deref.call(null,ret)));
} else {
return ret;
}
});

cljs.core.async.t_cljs$core$async5159.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async5159.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,val,fn1);
});

cljs.core.async.t_cljs$core$async5159.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta5160","meta5160",1526085478,null)], null);
});

cljs.core.async.t_cljs$core$async5159.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async5159.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async5159";

cljs.core.async.t_cljs$core$async5159.cljs$lang$ctorPrWriter = (function (this__4161__auto__,writer__4162__auto__,opt__4163__auto__){
return cljs.core._write.call(null,writer__4162__auto__,"cljs.core.async/t_cljs$core$async5159");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async5159.
 */
cljs.core.async.__GT_t_cljs$core$async5159 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async5159(f__$1,ch__$1,meta5160){
return (new cljs.core.async.t_cljs$core$async5159(f__$1,ch__$1,meta5160));
});

}

return (new cljs.core.async.t_cljs$core$async5159(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if(typeof cljs.core.async.t_cljs$core$async5165 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async5165 = (function (f,ch,meta5166){
this.f = f;
this.ch = ch;
this.meta5166 = meta5166;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async5165.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_5167,meta5166__$1){
var self__ = this;
var _5167__$1 = this;
return (new cljs.core.async.t_cljs$core$async5165(self__.f,self__.ch,meta5166__$1));
});

cljs.core.async.t_cljs$core$async5165.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_5167){
var self__ = this;
var _5167__$1 = this;
return self__.meta5166;
});

cljs.core.async.t_cljs$core$async5165.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async5165.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async5165.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async5165.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async5165.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async5165.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,self__.f.call(null,val),fn1);
});

cljs.core.async.t_cljs$core$async5165.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta5166","meta5166",2129594466,null)], null);
});

cljs.core.async.t_cljs$core$async5165.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async5165.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async5165";

cljs.core.async.t_cljs$core$async5165.cljs$lang$ctorPrWriter = (function (this__4161__auto__,writer__4162__auto__,opt__4163__auto__){
return cljs.core._write.call(null,writer__4162__auto__,"cljs.core.async/t_cljs$core$async5165");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async5165.
 */
cljs.core.async.__GT_t_cljs$core$async5165 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async5165(f__$1,ch__$1,meta5166){
return (new cljs.core.async.t_cljs$core$async5165(f__$1,ch__$1,meta5166));
});

}

return (new cljs.core.async.t_cljs$core$async5165(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if(typeof cljs.core.async.t_cljs$core$async5168 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async5168 = (function (p,ch,meta5169){
this.p = p;
this.ch = ch;
this.meta5169 = meta5169;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async5168.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_5170,meta5169__$1){
var self__ = this;
var _5170__$1 = this;
return (new cljs.core.async.t_cljs$core$async5168(self__.p,self__.ch,meta5169__$1));
});

cljs.core.async.t_cljs$core$async5168.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_5170){
var self__ = this;
var _5170__$1 = this;
return self__.meta5169;
});

cljs.core.async.t_cljs$core$async5168.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async5168.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async5168.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async5168.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async5168.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async5168.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async5168.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_(self__.p.call(null,val))){
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box.call(null,cljs.core.not.call(null,cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch)));
}
});

cljs.core.async.t_cljs$core$async5168.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"p","p",1791580836,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta5169","meta5169",-839667052,null)], null);
});

cljs.core.async.t_cljs$core$async5168.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async5168.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async5168";

cljs.core.async.t_cljs$core$async5168.cljs$lang$ctorPrWriter = (function (this__4161__auto__,writer__4162__auto__,opt__4163__auto__){
return cljs.core._write.call(null,writer__4162__auto__,"cljs.core.async/t_cljs$core$async5168");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async5168.
 */
cljs.core.async.__GT_t_cljs$core$async5168 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async5168(p__$1,ch__$1,meta5169){
return (new cljs.core.async.t_cljs$core$async5168(p__$1,ch__$1,meta5169));
});

}

return (new cljs.core.async.t_cljs$core$async5168(p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_.call(null,cljs.core.complement.call(null,p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var G__5172 = arguments.length;
switch (G__5172) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.call(null,p,ch,null);
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__3673__auto___5212 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___5212,out){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___5212,out){
return (function (state_5193){
var state_val_5194 = (state_5193[(1)]);
if((state_val_5194 === (7))){
var inst_5189 = (state_5193[(2)]);
var state_5193__$1 = state_5193;
var statearr_5195_5213 = state_5193__$1;
(statearr_5195_5213[(2)] = inst_5189);

(statearr_5195_5213[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5194 === (1))){
var state_5193__$1 = state_5193;
var statearr_5196_5214 = state_5193__$1;
(statearr_5196_5214[(2)] = null);

(statearr_5196_5214[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5194 === (4))){
var inst_5175 = (state_5193[(7)]);
var inst_5175__$1 = (state_5193[(2)]);
var inst_5176 = (inst_5175__$1 == null);
var state_5193__$1 = (function (){var statearr_5197 = state_5193;
(statearr_5197[(7)] = inst_5175__$1);

return statearr_5197;
})();
if(cljs.core.truth_(inst_5176)){
var statearr_5198_5215 = state_5193__$1;
(statearr_5198_5215[(1)] = (5));

} else {
var statearr_5199_5216 = state_5193__$1;
(statearr_5199_5216[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5194 === (6))){
var inst_5175 = (state_5193[(7)]);
var inst_5180 = p.call(null,inst_5175);
var state_5193__$1 = state_5193;
if(cljs.core.truth_(inst_5180)){
var statearr_5200_5217 = state_5193__$1;
(statearr_5200_5217[(1)] = (8));

} else {
var statearr_5201_5218 = state_5193__$1;
(statearr_5201_5218[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5194 === (3))){
var inst_5191 = (state_5193[(2)]);
var state_5193__$1 = state_5193;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_5193__$1,inst_5191);
} else {
if((state_val_5194 === (2))){
var state_5193__$1 = state_5193;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_5193__$1,(4),ch);
} else {
if((state_val_5194 === (11))){
var inst_5183 = (state_5193[(2)]);
var state_5193__$1 = state_5193;
var statearr_5202_5219 = state_5193__$1;
(statearr_5202_5219[(2)] = inst_5183);

(statearr_5202_5219[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5194 === (9))){
var state_5193__$1 = state_5193;
var statearr_5203_5220 = state_5193__$1;
(statearr_5203_5220[(2)] = null);

(statearr_5203_5220[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5194 === (5))){
var inst_5178 = cljs.core.async.close_BANG_.call(null,out);
var state_5193__$1 = state_5193;
var statearr_5204_5221 = state_5193__$1;
(statearr_5204_5221[(2)] = inst_5178);

(statearr_5204_5221[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5194 === (10))){
var inst_5186 = (state_5193[(2)]);
var state_5193__$1 = (function (){var statearr_5205 = state_5193;
(statearr_5205[(8)] = inst_5186);

return statearr_5205;
})();
var statearr_5206_5222 = state_5193__$1;
(statearr_5206_5222[(2)] = null);

(statearr_5206_5222[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5194 === (8))){
var inst_5175 = (state_5193[(7)]);
var state_5193__$1 = state_5193;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_5193__$1,(11),out,inst_5175);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___5212,out))
;
return ((function (switch__3583__auto__,c__3673__auto___5212,out){
return (function() {
var cljs$core$async$state_machine__3584__auto__ = null;
var cljs$core$async$state_machine__3584__auto____0 = (function (){
var statearr_5207 = [null,null,null,null,null,null,null,null,null];
(statearr_5207[(0)] = cljs$core$async$state_machine__3584__auto__);

(statearr_5207[(1)] = (1));

return statearr_5207;
});
var cljs$core$async$state_machine__3584__auto____1 = (function (state_5193){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_5193);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e5208){if((e5208 instanceof Object)){
var ex__3587__auto__ = e5208;
var statearr_5209_5223 = state_5193;
(statearr_5209_5223[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_5193);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e5208;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__5224 = state_5193;
state_5193 = G__5224;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$state_machine__3584__auto__ = function(state_5193){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__3584__auto____1.call(this,state_5193);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__3584__auto____0;
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__3584__auto____1;
return cljs$core$async$state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___5212,out))
})();
var state__3675__auto__ = (function (){var statearr_5210 = f__3674__auto__.call(null);
(statearr_5210[(6)] = c__3673__auto___5212);

return statearr_5210;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___5212,out))
);


return out;
});

cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var G__5226 = arguments.length;
switch (G__5226) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.call(null,p,ch,null);
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.call(null,cljs.core.complement.call(null,p),ch,buf_or_n);
});

cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3;

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__3673__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto__){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto__){
return (function (state_5289){
var state_val_5290 = (state_5289[(1)]);
if((state_val_5290 === (7))){
var inst_5285 = (state_5289[(2)]);
var state_5289__$1 = state_5289;
var statearr_5291_5329 = state_5289__$1;
(statearr_5291_5329[(2)] = inst_5285);

(statearr_5291_5329[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (20))){
var inst_5255 = (state_5289[(7)]);
var inst_5266 = (state_5289[(2)]);
var inst_5267 = cljs.core.next.call(null,inst_5255);
var inst_5241 = inst_5267;
var inst_5242 = null;
var inst_5243 = (0);
var inst_5244 = (0);
var state_5289__$1 = (function (){var statearr_5292 = state_5289;
(statearr_5292[(8)] = inst_5243);

(statearr_5292[(9)] = inst_5244);

(statearr_5292[(10)] = inst_5266);

(statearr_5292[(11)] = inst_5242);

(statearr_5292[(12)] = inst_5241);

return statearr_5292;
})();
var statearr_5293_5330 = state_5289__$1;
(statearr_5293_5330[(2)] = null);

(statearr_5293_5330[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (1))){
var state_5289__$1 = state_5289;
var statearr_5294_5331 = state_5289__$1;
(statearr_5294_5331[(2)] = null);

(statearr_5294_5331[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (4))){
var inst_5230 = (state_5289[(13)]);
var inst_5230__$1 = (state_5289[(2)]);
var inst_5231 = (inst_5230__$1 == null);
var state_5289__$1 = (function (){var statearr_5295 = state_5289;
(statearr_5295[(13)] = inst_5230__$1);

return statearr_5295;
})();
if(cljs.core.truth_(inst_5231)){
var statearr_5296_5332 = state_5289__$1;
(statearr_5296_5332[(1)] = (5));

} else {
var statearr_5297_5333 = state_5289__$1;
(statearr_5297_5333[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (15))){
var state_5289__$1 = state_5289;
var statearr_5301_5334 = state_5289__$1;
(statearr_5301_5334[(2)] = null);

(statearr_5301_5334[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (21))){
var state_5289__$1 = state_5289;
var statearr_5302_5335 = state_5289__$1;
(statearr_5302_5335[(2)] = null);

(statearr_5302_5335[(1)] = (23));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (13))){
var inst_5243 = (state_5289[(8)]);
var inst_5244 = (state_5289[(9)]);
var inst_5242 = (state_5289[(11)]);
var inst_5241 = (state_5289[(12)]);
var inst_5251 = (state_5289[(2)]);
var inst_5252 = (inst_5244 + (1));
var tmp5298 = inst_5243;
var tmp5299 = inst_5242;
var tmp5300 = inst_5241;
var inst_5241__$1 = tmp5300;
var inst_5242__$1 = tmp5299;
var inst_5243__$1 = tmp5298;
var inst_5244__$1 = inst_5252;
var state_5289__$1 = (function (){var statearr_5303 = state_5289;
(statearr_5303[(8)] = inst_5243__$1);

(statearr_5303[(9)] = inst_5244__$1);

(statearr_5303[(14)] = inst_5251);

(statearr_5303[(11)] = inst_5242__$1);

(statearr_5303[(12)] = inst_5241__$1);

return statearr_5303;
})();
var statearr_5304_5336 = state_5289__$1;
(statearr_5304_5336[(2)] = null);

(statearr_5304_5336[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (22))){
var state_5289__$1 = state_5289;
var statearr_5305_5337 = state_5289__$1;
(statearr_5305_5337[(2)] = null);

(statearr_5305_5337[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (6))){
var inst_5230 = (state_5289[(13)]);
var inst_5239 = f.call(null,inst_5230);
var inst_5240 = cljs.core.seq.call(null,inst_5239);
var inst_5241 = inst_5240;
var inst_5242 = null;
var inst_5243 = (0);
var inst_5244 = (0);
var state_5289__$1 = (function (){var statearr_5306 = state_5289;
(statearr_5306[(8)] = inst_5243);

(statearr_5306[(9)] = inst_5244);

(statearr_5306[(11)] = inst_5242);

(statearr_5306[(12)] = inst_5241);

return statearr_5306;
})();
var statearr_5307_5338 = state_5289__$1;
(statearr_5307_5338[(2)] = null);

(statearr_5307_5338[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (17))){
var inst_5255 = (state_5289[(7)]);
var inst_5259 = cljs.core.chunk_first.call(null,inst_5255);
var inst_5260 = cljs.core.chunk_rest.call(null,inst_5255);
var inst_5261 = cljs.core.count.call(null,inst_5259);
var inst_5241 = inst_5260;
var inst_5242 = inst_5259;
var inst_5243 = inst_5261;
var inst_5244 = (0);
var state_5289__$1 = (function (){var statearr_5308 = state_5289;
(statearr_5308[(8)] = inst_5243);

(statearr_5308[(9)] = inst_5244);

(statearr_5308[(11)] = inst_5242);

(statearr_5308[(12)] = inst_5241);

return statearr_5308;
})();
var statearr_5309_5339 = state_5289__$1;
(statearr_5309_5339[(2)] = null);

(statearr_5309_5339[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (3))){
var inst_5287 = (state_5289[(2)]);
var state_5289__$1 = state_5289;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_5289__$1,inst_5287);
} else {
if((state_val_5290 === (12))){
var inst_5275 = (state_5289[(2)]);
var state_5289__$1 = state_5289;
var statearr_5310_5340 = state_5289__$1;
(statearr_5310_5340[(2)] = inst_5275);

(statearr_5310_5340[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (2))){
var state_5289__$1 = state_5289;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_5289__$1,(4),in$);
} else {
if((state_val_5290 === (23))){
var inst_5283 = (state_5289[(2)]);
var state_5289__$1 = state_5289;
var statearr_5311_5341 = state_5289__$1;
(statearr_5311_5341[(2)] = inst_5283);

(statearr_5311_5341[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (19))){
var inst_5270 = (state_5289[(2)]);
var state_5289__$1 = state_5289;
var statearr_5312_5342 = state_5289__$1;
(statearr_5312_5342[(2)] = inst_5270);

(statearr_5312_5342[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (11))){
var inst_5255 = (state_5289[(7)]);
var inst_5241 = (state_5289[(12)]);
var inst_5255__$1 = cljs.core.seq.call(null,inst_5241);
var state_5289__$1 = (function (){var statearr_5313 = state_5289;
(statearr_5313[(7)] = inst_5255__$1);

return statearr_5313;
})();
if(inst_5255__$1){
var statearr_5314_5343 = state_5289__$1;
(statearr_5314_5343[(1)] = (14));

} else {
var statearr_5315_5344 = state_5289__$1;
(statearr_5315_5344[(1)] = (15));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (9))){
var inst_5277 = (state_5289[(2)]);
var inst_5278 = cljs.core.async.impl.protocols.closed_QMARK_.call(null,out);
var state_5289__$1 = (function (){var statearr_5316 = state_5289;
(statearr_5316[(15)] = inst_5277);

return statearr_5316;
})();
if(cljs.core.truth_(inst_5278)){
var statearr_5317_5345 = state_5289__$1;
(statearr_5317_5345[(1)] = (21));

} else {
var statearr_5318_5346 = state_5289__$1;
(statearr_5318_5346[(1)] = (22));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (5))){
var inst_5233 = cljs.core.async.close_BANG_.call(null,out);
var state_5289__$1 = state_5289;
var statearr_5319_5347 = state_5289__$1;
(statearr_5319_5347[(2)] = inst_5233);

(statearr_5319_5347[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (14))){
var inst_5255 = (state_5289[(7)]);
var inst_5257 = cljs.core.chunked_seq_QMARK_.call(null,inst_5255);
var state_5289__$1 = state_5289;
if(inst_5257){
var statearr_5320_5348 = state_5289__$1;
(statearr_5320_5348[(1)] = (17));

} else {
var statearr_5321_5349 = state_5289__$1;
(statearr_5321_5349[(1)] = (18));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (16))){
var inst_5273 = (state_5289[(2)]);
var state_5289__$1 = state_5289;
var statearr_5322_5350 = state_5289__$1;
(statearr_5322_5350[(2)] = inst_5273);

(statearr_5322_5350[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5290 === (10))){
var inst_5244 = (state_5289[(9)]);
var inst_5242 = (state_5289[(11)]);
var inst_5249 = cljs.core._nth.call(null,inst_5242,inst_5244);
var state_5289__$1 = state_5289;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_5289__$1,(13),out,inst_5249);
} else {
if((state_val_5290 === (18))){
var inst_5255 = (state_5289[(7)]);
var inst_5264 = cljs.core.first.call(null,inst_5255);
var state_5289__$1 = state_5289;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_5289__$1,(20),out,inst_5264);
} else {
if((state_val_5290 === (8))){
var inst_5243 = (state_5289[(8)]);
var inst_5244 = (state_5289[(9)]);
var inst_5246 = (inst_5244 < inst_5243);
var inst_5247 = inst_5246;
var state_5289__$1 = state_5289;
if(cljs.core.truth_(inst_5247)){
var statearr_5323_5351 = state_5289__$1;
(statearr_5323_5351[(1)] = (10));

} else {
var statearr_5324_5352 = state_5289__$1;
(statearr_5324_5352[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto__))
;
return ((function (switch__3583__auto__,c__3673__auto__){
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__3584__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__3584__auto____0 = (function (){
var statearr_5325 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_5325[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__3584__auto__);

(statearr_5325[(1)] = (1));

return statearr_5325;
});
var cljs$core$async$mapcat_STAR__$_state_machine__3584__auto____1 = (function (state_5289){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_5289);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e5326){if((e5326 instanceof Object)){
var ex__3587__auto__ = e5326;
var statearr_5327_5353 = state_5289;
(statearr_5327_5353[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_5289);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e5326;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__5354 = state_5289;
state_5289 = G__5354;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__3584__auto__ = function(state_5289){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__3584__auto____1.call(this,state_5289);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$mapcat_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__3584__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__3584__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto__))
})();
var state__3675__auto__ = (function (){var statearr_5328 = f__3674__auto__.call(null);
(statearr_5328[(6)] = c__3673__auto__);

return statearr_5328;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto__))
);

return c__3673__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var G__5356 = arguments.length;
switch (G__5356) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.call(null,f,in$,null);
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
cljs.core.async.mapcat_STAR_.call(null,f,in$,out);

return out;
});

cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var G__5359 = arguments.length;
switch (G__5359) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.call(null,f,out,null);
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.call(null,buf_or_n);
cljs.core.async.mapcat_STAR_.call(null,f,in$,out);

return in$;
});

cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var G__5362 = arguments.length;
switch (G__5362) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.call(null,ch,null);
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__3673__auto___5409 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___5409,out){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___5409,out){
return (function (state_5386){
var state_val_5387 = (state_5386[(1)]);
if((state_val_5387 === (7))){
var inst_5381 = (state_5386[(2)]);
var state_5386__$1 = state_5386;
var statearr_5388_5410 = state_5386__$1;
(statearr_5388_5410[(2)] = inst_5381);

(statearr_5388_5410[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5387 === (1))){
var inst_5363 = null;
var state_5386__$1 = (function (){var statearr_5389 = state_5386;
(statearr_5389[(7)] = inst_5363);

return statearr_5389;
})();
var statearr_5390_5411 = state_5386__$1;
(statearr_5390_5411[(2)] = null);

(statearr_5390_5411[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5387 === (4))){
var inst_5366 = (state_5386[(8)]);
var inst_5366__$1 = (state_5386[(2)]);
var inst_5367 = (inst_5366__$1 == null);
var inst_5368 = cljs.core.not.call(null,inst_5367);
var state_5386__$1 = (function (){var statearr_5391 = state_5386;
(statearr_5391[(8)] = inst_5366__$1);

return statearr_5391;
})();
if(inst_5368){
var statearr_5392_5412 = state_5386__$1;
(statearr_5392_5412[(1)] = (5));

} else {
var statearr_5393_5413 = state_5386__$1;
(statearr_5393_5413[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5387 === (6))){
var state_5386__$1 = state_5386;
var statearr_5394_5414 = state_5386__$1;
(statearr_5394_5414[(2)] = null);

(statearr_5394_5414[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5387 === (3))){
var inst_5383 = (state_5386[(2)]);
var inst_5384 = cljs.core.async.close_BANG_.call(null,out);
var state_5386__$1 = (function (){var statearr_5395 = state_5386;
(statearr_5395[(9)] = inst_5383);

return statearr_5395;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_5386__$1,inst_5384);
} else {
if((state_val_5387 === (2))){
var state_5386__$1 = state_5386;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_5386__$1,(4),ch);
} else {
if((state_val_5387 === (11))){
var inst_5366 = (state_5386[(8)]);
var inst_5375 = (state_5386[(2)]);
var inst_5363 = inst_5366;
var state_5386__$1 = (function (){var statearr_5396 = state_5386;
(statearr_5396[(7)] = inst_5363);

(statearr_5396[(10)] = inst_5375);

return statearr_5396;
})();
var statearr_5397_5415 = state_5386__$1;
(statearr_5397_5415[(2)] = null);

(statearr_5397_5415[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5387 === (9))){
var inst_5366 = (state_5386[(8)]);
var state_5386__$1 = state_5386;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_5386__$1,(11),out,inst_5366);
} else {
if((state_val_5387 === (5))){
var inst_5363 = (state_5386[(7)]);
var inst_5366 = (state_5386[(8)]);
var inst_5370 = cljs.core._EQ_.call(null,inst_5366,inst_5363);
var state_5386__$1 = state_5386;
if(inst_5370){
var statearr_5399_5416 = state_5386__$1;
(statearr_5399_5416[(1)] = (8));

} else {
var statearr_5400_5417 = state_5386__$1;
(statearr_5400_5417[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5387 === (10))){
var inst_5378 = (state_5386[(2)]);
var state_5386__$1 = state_5386;
var statearr_5401_5418 = state_5386__$1;
(statearr_5401_5418[(2)] = inst_5378);

(statearr_5401_5418[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5387 === (8))){
var inst_5363 = (state_5386[(7)]);
var tmp5398 = inst_5363;
var inst_5363__$1 = tmp5398;
var state_5386__$1 = (function (){var statearr_5402 = state_5386;
(statearr_5402[(7)] = inst_5363__$1);

return statearr_5402;
})();
var statearr_5403_5419 = state_5386__$1;
(statearr_5403_5419[(2)] = null);

(statearr_5403_5419[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___5409,out))
;
return ((function (switch__3583__auto__,c__3673__auto___5409,out){
return (function() {
var cljs$core$async$state_machine__3584__auto__ = null;
var cljs$core$async$state_machine__3584__auto____0 = (function (){
var statearr_5404 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_5404[(0)] = cljs$core$async$state_machine__3584__auto__);

(statearr_5404[(1)] = (1));

return statearr_5404;
});
var cljs$core$async$state_machine__3584__auto____1 = (function (state_5386){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_5386);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e5405){if((e5405 instanceof Object)){
var ex__3587__auto__ = e5405;
var statearr_5406_5420 = state_5386;
(statearr_5406_5420[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_5386);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e5405;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__5421 = state_5386;
state_5386 = G__5421;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$state_machine__3584__auto__ = function(state_5386){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__3584__auto____1.call(this,state_5386);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__3584__auto____0;
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__3584__auto____1;
return cljs$core$async$state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___5409,out))
})();
var state__3675__auto__ = (function (){var statearr_5407 = f__3674__auto__.call(null);
(statearr_5407[(6)] = c__3673__auto___5409);

return statearr_5407;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___5409,out))
);


return out;
});

cljs.core.async.unique.cljs$lang$maxFixedArity = 2;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var G__5423 = arguments.length;
switch (G__5423) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.call(null,n,ch,null);
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__3673__auto___5489 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___5489,out){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___5489,out){
return (function (state_5461){
var state_val_5462 = (state_5461[(1)]);
if((state_val_5462 === (7))){
var inst_5457 = (state_5461[(2)]);
var state_5461__$1 = state_5461;
var statearr_5463_5490 = state_5461__$1;
(statearr_5463_5490[(2)] = inst_5457);

(statearr_5463_5490[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5462 === (1))){
var inst_5424 = (new Array(n));
var inst_5425 = inst_5424;
var inst_5426 = (0);
var state_5461__$1 = (function (){var statearr_5464 = state_5461;
(statearr_5464[(7)] = inst_5426);

(statearr_5464[(8)] = inst_5425);

return statearr_5464;
})();
var statearr_5465_5491 = state_5461__$1;
(statearr_5465_5491[(2)] = null);

(statearr_5465_5491[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5462 === (4))){
var inst_5429 = (state_5461[(9)]);
var inst_5429__$1 = (state_5461[(2)]);
var inst_5430 = (inst_5429__$1 == null);
var inst_5431 = cljs.core.not.call(null,inst_5430);
var state_5461__$1 = (function (){var statearr_5466 = state_5461;
(statearr_5466[(9)] = inst_5429__$1);

return statearr_5466;
})();
if(inst_5431){
var statearr_5467_5492 = state_5461__$1;
(statearr_5467_5492[(1)] = (5));

} else {
var statearr_5468_5493 = state_5461__$1;
(statearr_5468_5493[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5462 === (15))){
var inst_5451 = (state_5461[(2)]);
var state_5461__$1 = state_5461;
var statearr_5469_5494 = state_5461__$1;
(statearr_5469_5494[(2)] = inst_5451);

(statearr_5469_5494[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5462 === (13))){
var state_5461__$1 = state_5461;
var statearr_5470_5495 = state_5461__$1;
(statearr_5470_5495[(2)] = null);

(statearr_5470_5495[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5462 === (6))){
var inst_5426 = (state_5461[(7)]);
var inst_5447 = (inst_5426 > (0));
var state_5461__$1 = state_5461;
if(cljs.core.truth_(inst_5447)){
var statearr_5471_5496 = state_5461__$1;
(statearr_5471_5496[(1)] = (12));

} else {
var statearr_5472_5497 = state_5461__$1;
(statearr_5472_5497[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5462 === (3))){
var inst_5459 = (state_5461[(2)]);
var state_5461__$1 = state_5461;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_5461__$1,inst_5459);
} else {
if((state_val_5462 === (12))){
var inst_5425 = (state_5461[(8)]);
var inst_5449 = cljs.core.vec.call(null,inst_5425);
var state_5461__$1 = state_5461;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_5461__$1,(15),out,inst_5449);
} else {
if((state_val_5462 === (2))){
var state_5461__$1 = state_5461;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_5461__$1,(4),ch);
} else {
if((state_val_5462 === (11))){
var inst_5441 = (state_5461[(2)]);
var inst_5442 = (new Array(n));
var inst_5425 = inst_5442;
var inst_5426 = (0);
var state_5461__$1 = (function (){var statearr_5473 = state_5461;
(statearr_5473[(7)] = inst_5426);

(statearr_5473[(10)] = inst_5441);

(statearr_5473[(8)] = inst_5425);

return statearr_5473;
})();
var statearr_5474_5498 = state_5461__$1;
(statearr_5474_5498[(2)] = null);

(statearr_5474_5498[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5462 === (9))){
var inst_5425 = (state_5461[(8)]);
var inst_5439 = cljs.core.vec.call(null,inst_5425);
var state_5461__$1 = state_5461;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_5461__$1,(11),out,inst_5439);
} else {
if((state_val_5462 === (5))){
var inst_5426 = (state_5461[(7)]);
var inst_5429 = (state_5461[(9)]);
var inst_5425 = (state_5461[(8)]);
var inst_5434 = (state_5461[(11)]);
var inst_5433 = (inst_5425[inst_5426] = inst_5429);
var inst_5434__$1 = (inst_5426 + (1));
var inst_5435 = (inst_5434__$1 < n);
var state_5461__$1 = (function (){var statearr_5475 = state_5461;
(statearr_5475[(12)] = inst_5433);

(statearr_5475[(11)] = inst_5434__$1);

return statearr_5475;
})();
if(cljs.core.truth_(inst_5435)){
var statearr_5476_5499 = state_5461__$1;
(statearr_5476_5499[(1)] = (8));

} else {
var statearr_5477_5500 = state_5461__$1;
(statearr_5477_5500[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5462 === (14))){
var inst_5454 = (state_5461[(2)]);
var inst_5455 = cljs.core.async.close_BANG_.call(null,out);
var state_5461__$1 = (function (){var statearr_5479 = state_5461;
(statearr_5479[(13)] = inst_5454);

return statearr_5479;
})();
var statearr_5480_5501 = state_5461__$1;
(statearr_5480_5501[(2)] = inst_5455);

(statearr_5480_5501[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5462 === (10))){
var inst_5445 = (state_5461[(2)]);
var state_5461__$1 = state_5461;
var statearr_5481_5502 = state_5461__$1;
(statearr_5481_5502[(2)] = inst_5445);

(statearr_5481_5502[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5462 === (8))){
var inst_5425 = (state_5461[(8)]);
var inst_5434 = (state_5461[(11)]);
var tmp5478 = inst_5425;
var inst_5425__$1 = tmp5478;
var inst_5426 = inst_5434;
var state_5461__$1 = (function (){var statearr_5482 = state_5461;
(statearr_5482[(7)] = inst_5426);

(statearr_5482[(8)] = inst_5425__$1);

return statearr_5482;
})();
var statearr_5483_5503 = state_5461__$1;
(statearr_5483_5503[(2)] = null);

(statearr_5483_5503[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___5489,out))
;
return ((function (switch__3583__auto__,c__3673__auto___5489,out){
return (function() {
var cljs$core$async$state_machine__3584__auto__ = null;
var cljs$core$async$state_machine__3584__auto____0 = (function (){
var statearr_5484 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_5484[(0)] = cljs$core$async$state_machine__3584__auto__);

(statearr_5484[(1)] = (1));

return statearr_5484;
});
var cljs$core$async$state_machine__3584__auto____1 = (function (state_5461){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_5461);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e5485){if((e5485 instanceof Object)){
var ex__3587__auto__ = e5485;
var statearr_5486_5504 = state_5461;
(statearr_5486_5504[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_5461);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e5485;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__5505 = state_5461;
state_5461 = G__5505;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$state_machine__3584__auto__ = function(state_5461){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__3584__auto____1.call(this,state_5461);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__3584__auto____0;
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__3584__auto____1;
return cljs$core$async$state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___5489,out))
})();
var state__3675__auto__ = (function (){var statearr_5487 = f__3674__auto__.call(null);
(statearr_5487[(6)] = c__3673__auto___5489);

return statearr_5487;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___5489,out))
);


return out;
});

cljs.core.async.partition.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var G__5507 = arguments.length;
switch (G__5507) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.call(null,f,ch,null);
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__3673__auto___5577 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__3673__auto___5577,out){
return (function (){
var f__3674__auto__ = (function (){var switch__3583__auto__ = ((function (c__3673__auto___5577,out){
return (function (state_5549){
var state_val_5550 = (state_5549[(1)]);
if((state_val_5550 === (7))){
var inst_5545 = (state_5549[(2)]);
var state_5549__$1 = state_5549;
var statearr_5551_5578 = state_5549__$1;
(statearr_5551_5578[(2)] = inst_5545);

(statearr_5551_5578[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5550 === (1))){
var inst_5508 = [];
var inst_5509 = inst_5508;
var inst_5510 = new cljs.core.Keyword("cljs.core.async","nothing","cljs.core.async/nothing",-69252123);
var state_5549__$1 = (function (){var statearr_5552 = state_5549;
(statearr_5552[(7)] = inst_5510);

(statearr_5552[(8)] = inst_5509);

return statearr_5552;
})();
var statearr_5553_5579 = state_5549__$1;
(statearr_5553_5579[(2)] = null);

(statearr_5553_5579[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5550 === (4))){
var inst_5513 = (state_5549[(9)]);
var inst_5513__$1 = (state_5549[(2)]);
var inst_5514 = (inst_5513__$1 == null);
var inst_5515 = cljs.core.not.call(null,inst_5514);
var state_5549__$1 = (function (){var statearr_5554 = state_5549;
(statearr_5554[(9)] = inst_5513__$1);

return statearr_5554;
})();
if(inst_5515){
var statearr_5555_5580 = state_5549__$1;
(statearr_5555_5580[(1)] = (5));

} else {
var statearr_5556_5581 = state_5549__$1;
(statearr_5556_5581[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5550 === (15))){
var inst_5539 = (state_5549[(2)]);
var state_5549__$1 = state_5549;
var statearr_5557_5582 = state_5549__$1;
(statearr_5557_5582[(2)] = inst_5539);

(statearr_5557_5582[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5550 === (13))){
var state_5549__$1 = state_5549;
var statearr_5558_5583 = state_5549__$1;
(statearr_5558_5583[(2)] = null);

(statearr_5558_5583[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5550 === (6))){
var inst_5509 = (state_5549[(8)]);
var inst_5534 = inst_5509.length;
var inst_5535 = (inst_5534 > (0));
var state_5549__$1 = state_5549;
if(cljs.core.truth_(inst_5535)){
var statearr_5559_5584 = state_5549__$1;
(statearr_5559_5584[(1)] = (12));

} else {
var statearr_5560_5585 = state_5549__$1;
(statearr_5560_5585[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5550 === (3))){
var inst_5547 = (state_5549[(2)]);
var state_5549__$1 = state_5549;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_5549__$1,inst_5547);
} else {
if((state_val_5550 === (12))){
var inst_5509 = (state_5549[(8)]);
var inst_5537 = cljs.core.vec.call(null,inst_5509);
var state_5549__$1 = state_5549;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_5549__$1,(15),out,inst_5537);
} else {
if((state_val_5550 === (2))){
var state_5549__$1 = state_5549;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_5549__$1,(4),ch);
} else {
if((state_val_5550 === (11))){
var inst_5517 = (state_5549[(10)]);
var inst_5513 = (state_5549[(9)]);
var inst_5527 = (state_5549[(2)]);
var inst_5528 = [];
var inst_5529 = inst_5528.push(inst_5513);
var inst_5509 = inst_5528;
var inst_5510 = inst_5517;
var state_5549__$1 = (function (){var statearr_5561 = state_5549;
(statearr_5561[(7)] = inst_5510);

(statearr_5561[(11)] = inst_5527);

(statearr_5561[(12)] = inst_5529);

(statearr_5561[(8)] = inst_5509);

return statearr_5561;
})();
var statearr_5562_5586 = state_5549__$1;
(statearr_5562_5586[(2)] = null);

(statearr_5562_5586[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5550 === (9))){
var inst_5509 = (state_5549[(8)]);
var inst_5525 = cljs.core.vec.call(null,inst_5509);
var state_5549__$1 = state_5549;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_5549__$1,(11),out,inst_5525);
} else {
if((state_val_5550 === (5))){
var inst_5510 = (state_5549[(7)]);
var inst_5517 = (state_5549[(10)]);
var inst_5513 = (state_5549[(9)]);
var inst_5517__$1 = f.call(null,inst_5513);
var inst_5518 = cljs.core._EQ_.call(null,inst_5517__$1,inst_5510);
var inst_5519 = cljs.core.keyword_identical_QMARK_.call(null,inst_5510,new cljs.core.Keyword("cljs.core.async","nothing","cljs.core.async/nothing",-69252123));
var inst_5520 = ((inst_5518) || (inst_5519));
var state_5549__$1 = (function (){var statearr_5563 = state_5549;
(statearr_5563[(10)] = inst_5517__$1);

return statearr_5563;
})();
if(cljs.core.truth_(inst_5520)){
var statearr_5564_5587 = state_5549__$1;
(statearr_5564_5587[(1)] = (8));

} else {
var statearr_5565_5588 = state_5549__$1;
(statearr_5565_5588[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5550 === (14))){
var inst_5542 = (state_5549[(2)]);
var inst_5543 = cljs.core.async.close_BANG_.call(null,out);
var state_5549__$1 = (function (){var statearr_5567 = state_5549;
(statearr_5567[(13)] = inst_5542);

return statearr_5567;
})();
var statearr_5568_5589 = state_5549__$1;
(statearr_5568_5589[(2)] = inst_5543);

(statearr_5568_5589[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5550 === (10))){
var inst_5532 = (state_5549[(2)]);
var state_5549__$1 = state_5549;
var statearr_5569_5590 = state_5549__$1;
(statearr_5569_5590[(2)] = inst_5532);

(statearr_5569_5590[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_5550 === (8))){
var inst_5517 = (state_5549[(10)]);
var inst_5513 = (state_5549[(9)]);
var inst_5509 = (state_5549[(8)]);
var inst_5522 = inst_5509.push(inst_5513);
var tmp5566 = inst_5509;
var inst_5509__$1 = tmp5566;
var inst_5510 = inst_5517;
var state_5549__$1 = (function (){var statearr_5570 = state_5549;
(statearr_5570[(7)] = inst_5510);

(statearr_5570[(8)] = inst_5509__$1);

(statearr_5570[(14)] = inst_5522);

return statearr_5570;
})();
var statearr_5571_5591 = state_5549__$1;
(statearr_5571_5591[(2)] = null);

(statearr_5571_5591[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__3673__auto___5577,out))
;
return ((function (switch__3583__auto__,c__3673__auto___5577,out){
return (function() {
var cljs$core$async$state_machine__3584__auto__ = null;
var cljs$core$async$state_machine__3584__auto____0 = (function (){
var statearr_5572 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_5572[(0)] = cljs$core$async$state_machine__3584__auto__);

(statearr_5572[(1)] = (1));

return statearr_5572;
});
var cljs$core$async$state_machine__3584__auto____1 = (function (state_5549){
while(true){
var ret_value__3585__auto__ = (function (){try{while(true){
var result__3586__auto__ = switch__3583__auto__.call(null,state_5549);
if(cljs.core.keyword_identical_QMARK_.call(null,result__3586__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__3586__auto__;
}
break;
}
}catch (e5573){if((e5573 instanceof Object)){
var ex__3587__auto__ = e5573;
var statearr_5574_5592 = state_5549;
(statearr_5574_5592[(5)] = ex__3587__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_5549);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e5573;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__3585__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__5593 = state_5549;
state_5549 = G__5593;
continue;
} else {
return ret_value__3585__auto__;
}
break;
}
});
cljs$core$async$state_machine__3584__auto__ = function(state_5549){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__3584__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__3584__auto____1.call(this,state_5549);
}
throw(new Error('Invalid arity: ' + (arguments.length - 1)));
};
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__3584__auto____0;
cljs$core$async$state_machine__3584__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__3584__auto____1;
return cljs$core$async$state_machine__3584__auto__;
})()
;})(switch__3583__auto__,c__3673__auto___5577,out))
})();
var state__3675__auto__ = (function (){var statearr_5575 = f__3674__auto__.call(null);
(statearr_5575[(6)] = c__3673__auto___5577);

return statearr_5575;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__3675__auto__);
});})(c__3673__auto___5577,out))
);


return out;
});

cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3;


//# sourceMappingURL=async.js.map

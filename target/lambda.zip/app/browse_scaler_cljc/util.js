// Compiled by ClojureScript 1.10.238 {:target :nodejs}
goog.provide('browse_scaler_cljc.util');
goog.require('cljs.core');
goog.require('cljs.core.async');
goog.require('cljs.nodejs');
goog.require('cljs.pprint');
goog.require('cljs.reader');
goog.require('clojure.string');
browse_scaler_cljc.util.fs = cljs.nodejs.require.call(null,"fs");
browse_scaler_cljc.util.stream = require("stream");
browse_scaler_cljc.util.js_url = require("url");
browse_scaler_cljc.util.eol = require("os").EOL;
browse_scaler_cljc.util.node_slurp = (function browse_scaler_cljc$util$node_slurp(path){
return browse_scaler_cljc.util.fs.readFileSync(path,"utf8");
});
browse_scaler_cljc.util.config = browse_scaler_cljc.util.node_slurp.call(null,"static/config.edn");
browse_scaler_cljc.util.cmr_search_root = new cljs.core.Keyword(null,"cmr-search-root","cmr-search-root",2004825917).cljs$core$IFn$_invoke$arity$1(browse_scaler_cljc.util.config);
browse_scaler_cljc.util.browse_rel = "http://esipfed.org/ns/fedsearch/1.1/browse#";
browse_scaler_cljc.util.tmp_image_dir = "/tmp";

//# sourceMappingURL=util.js.map

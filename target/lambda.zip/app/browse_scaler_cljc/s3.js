// Compiled by ClojureScript 1.10.238 {:target :nodejs}
goog.provide('browse_scaler_cljc.s3');
goog.require('cljs.core');
goog.require('cljs.core.async');
goog.require('cljs.nodejs');
goog.require('cljs.pprint');
goog.require('cljs.reader');
goog.require('clojure.string');
if(typeof browse_scaler_cljc.s3.AWS !== 'undefined'){
} else {
browse_scaler_cljc.s3.AWS = require("aws-sdk");
}
browse_scaler_cljc.s3.s3_bucket_name = new cljs.core.Keyword(null,"s3-bucket-name","s3-bucket-name",1849765183).cljs$core$IFn$_invoke$arity$1(browse_scaler_cljc.s3.config);
browse_scaler_cljc.s3.s3_base_url = ["https://s3.amazonaws.com/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(browse_scaler_cljc.s3.s3_bucket_name)].join('');
browse_scaler_cljc.s3.s3_client = (function browse_scaler_cljc$s3$s3_client(){
return (new browse_scaler_cljc.s3.AWS.S3());
});
browse_scaler_cljc.s3.list_buckets = (function browse_scaler_cljc$s3$list_buckets(s3_client,result_handler){
return s3_client.listBuckets(({}),result_handler);
});
browse_scaler_cljc.s3.pretty_print_result_handler = (function browse_scaler_cljc$s3$pretty_print_result_handler(error,result){
if(cljs.core.truth_(error)){
return cljs.core.println.call(null,"ERROR !!!",error);
} else {
return cljs.core.println.call(null,cljs.pprint.pprint.call(null,cljs.core.js__GT_clj.call(null,result)));
}
});
/**
 * Return the S3 URL for a file basename
 */
browse_scaler_cljc.s3.s3_url = (function browse_scaler_cljc$s3$s3_url(basename){
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1(browse_scaler_cljc.s3.s3_base_url),"/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(basename)].join('');
});
/**
 * Save a file into S3
 */
browse_scaler_cljc.s3.cache_in_s3 = (function browse_scaler_cljc$s3$cache_in_s3(path){
var key = cljs.core.last.call(null,clojure.string.split.call(null,path,/\//));
cljs.core.println.call(null,"s3/put-object  ",browse_scaler_cljc.s3.s3_bucket_name," ",key);

s3_client.waitFor("putObject",cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"Bucket","Bucket",754730311),browse_scaler_cljc.s3.s3_bucket_name,new cljs.core.Keyword(null,"Key","Key",1553874408),key], null)));

return browse_scaler_cljc.s3.s3_url.call(null,key);
});
browse_scaler_cljc.s3.get_from_s3 = (function browse_scaler_cljc$s3$get_from_s3(path_or_key){
var key = cljs.core.last.call(null,clojure.string.split.call(null,path_or_key,/\//));
return s3_client.waitFor("getObject",cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"Bucket","Bucket",754730311),browse_scaler_cljc.s3.s3_bucket_name,new cljs.core.Keyword(null,"Key","Key",1553874408),key], null)));
});
browse_scaler_cljc.s3.exists_in_s3_QMARK_ = (function browse_scaler_cljc$s3$exists_in_s3_QMARK_(path_or_key){
var params = cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"Bucket","Bucket",754730311),browse_scaler_cljc.s3.s3_bucket_name,new cljs.core.Keyword(null,"Key","Key",1553874408),cljs.core.key], null));
var key = cljs.core.last.call(null,clojure.string.split.call(null,path_or_key,/\//));
return s3_client.waitFor("objectExists",params,cljs.core.true_QMARK_);
});

/**
* @constructor
 * @implements {cljs.core.IRecord}
 * @implements {cljs.core.IEquiv}
 * @implements {cljs.core.IHash}
 * @implements {cljs.core.ICollection}
 * @implements {cljs.core.ICounted}
 * @implements {cljs.core.ISeqable}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.ICloneable}
 * @implements {cljs.core.IPrintWithWriter}
 * @implements {cljs.core.IIterable}
 * @implements {cljs.core.IWithMeta}
 * @implements {cljs.core.IAssociative}
 * @implements {cljs.core.IMap}
 * @implements {cljs.core.ILookup}
*/
browse_scaler_cljc.s3.S3Client = (function (cache_item,get_item,exists_QMARK_,list_buckets,__meta,__extmap,__hash){
this.cache_item = cache_item;
this.get_item = get_item;
this.exists_QMARK_ = exists_QMARK_;
this.list_buckets = list_buckets;
this.__meta = __meta;
this.__extmap = __extmap;
this.__hash = __hash;
this.cljs$lang$protocol_mask$partition0$ = 2229667594;
this.cljs$lang$protocol_mask$partition1$ = 139264;
});
browse_scaler_cljc.s3.S3Client.prototype.cljs$core$ILookup$_lookup$arity$2 = (function (this__4172__auto__,k__4173__auto__){
var self__ = this;
var this__4172__auto____$1 = this;
return this__4172__auto____$1.cljs$core$ILookup$_lookup$arity$3(null,k__4173__auto__,null);
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$ILookup$_lookup$arity$3 = (function (this__4174__auto__,k6776,else__4175__auto__){
var self__ = this;
var this__4174__auto____$1 = this;
var G__6780 = k6776;
var G__6780__$1 = (((G__6780 instanceof cljs.core.Keyword))?G__6780.fqn:null);
switch (G__6780__$1) {
case "cache-item":
return self__.cache_item;

break;
case "get-item":
return self__.get_item;

break;
case "exists?":
return self__.exists_QMARK_;

break;
case "list-buckets":
return self__.list_buckets;

break;
default:
return cljs.core.get.call(null,self__.__extmap,k6776,else__4175__auto__);

}
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$IPrintWithWriter$_pr_writer$arity$3 = (function (this__4186__auto__,writer__4187__auto__,opts__4188__auto__){
var self__ = this;
var this__4186__auto____$1 = this;
var pr_pair__4189__auto__ = ((function (this__4186__auto____$1){
return (function (keyval__4190__auto__){
return cljs.core.pr_sequential_writer.call(null,writer__4187__auto__,cljs.core.pr_writer,""," ","",opts__4188__auto__,keyval__4190__auto__);
});})(this__4186__auto____$1))
;
return cljs.core.pr_sequential_writer.call(null,writer__4187__auto__,pr_pair__4189__auto__,"#browse-scaler-cljc.s3.S3Client{",", ","}",opts__4188__auto__,cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"cache-item","cache-item",-1193647857),self__.cache_item],null)),(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"get-item","get-item",-445412473),self__.get_item],null)),(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"exists?","exists?",1414473716),self__.exists_QMARK_],null)),(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"list-buckets","list-buckets",265873227),self__.list_buckets],null))], null),self__.__extmap));
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$IIterable$_iterator$arity$1 = (function (G__6775){
var self__ = this;
var G__6775__$1 = this;
return (new cljs.core.RecordIter((0),G__6775__$1,4,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"cache-item","cache-item",-1193647857),new cljs.core.Keyword(null,"get-item","get-item",-445412473),new cljs.core.Keyword(null,"exists?","exists?",1414473716),new cljs.core.Keyword(null,"list-buckets","list-buckets",265873227)], null),(cljs.core.truth_(self__.__extmap)?cljs.core._iterator.call(null,self__.__extmap):cljs.core.nil_iter.call(null))));
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$IMeta$_meta$arity$1 = (function (this__4170__auto__){
var self__ = this;
var this__4170__auto____$1 = this;
return self__.__meta;
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$ICloneable$_clone$arity$1 = (function (this__4167__auto__){
var self__ = this;
var this__4167__auto____$1 = this;
return (new browse_scaler_cljc.s3.S3Client(self__.cache_item,self__.get_item,self__.exists_QMARK_,self__.list_buckets,self__.__meta,self__.__extmap,self__.__hash));
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$ICounted$_count$arity$1 = (function (this__4176__auto__){
var self__ = this;
var this__4176__auto____$1 = this;
return (4 + cljs.core.count.call(null,self__.__extmap));
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$IHash$_hash$arity$1 = (function (this__4168__auto__){
var self__ = this;
var this__4168__auto____$1 = this;
var h__4030__auto__ = self__.__hash;
if(!((h__4030__auto__ == null))){
return h__4030__auto__;
} else {
var h__4030__auto____$1 = ((function (h__4030__auto__,this__4168__auto____$1){
return (function (coll__4169__auto__){
return (-343381061 ^ cljs.core.hash_unordered_coll.call(null,coll__4169__auto__));
});})(h__4030__auto__,this__4168__auto____$1))
.call(null,this__4168__auto____$1);
self__.__hash = h__4030__auto____$1;

return h__4030__auto____$1;
}
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$IEquiv$_equiv$arity$2 = (function (this6777,other6778){
var self__ = this;
var this6777__$1 = this;
return ((!((other6778 == null))) && ((this6777__$1.constructor === other6778.constructor)) && (cljs.core._EQ_.call(null,this6777__$1.cache_item,other6778.cache_item)) && (cljs.core._EQ_.call(null,this6777__$1.get_item,other6778.get_item)) && (cljs.core._EQ_.call(null,this6777__$1.exists_QMARK_,other6778.exists_QMARK_)) && (cljs.core._EQ_.call(null,this6777__$1.list_buckets,other6778.list_buckets)) && (cljs.core._EQ_.call(null,this6777__$1.__extmap,other6778.__extmap)));
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$IMap$_dissoc$arity$2 = (function (this__4181__auto__,k__4182__auto__){
var self__ = this;
var this__4181__auto____$1 = this;
if(cljs.core.contains_QMARK_.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"get-item","get-item",-445412473),null,new cljs.core.Keyword(null,"list-buckets","list-buckets",265873227),null,new cljs.core.Keyword(null,"cache-item","cache-item",-1193647857),null,new cljs.core.Keyword(null,"exists?","exists?",1414473716),null], null), null),k__4182__auto__)){
return cljs.core.dissoc.call(null,cljs.core._with_meta.call(null,cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,this__4181__auto____$1),self__.__meta),k__4182__auto__);
} else {
return (new browse_scaler_cljc.s3.S3Client(self__.cache_item,self__.get_item,self__.exists_QMARK_,self__.list_buckets,self__.__meta,cljs.core.not_empty.call(null,cljs.core.dissoc.call(null,self__.__extmap,k__4182__auto__)),null));
}
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$IAssociative$_assoc$arity$3 = (function (this__4179__auto__,k__4180__auto__,G__6775){
var self__ = this;
var this__4179__auto____$1 = this;
var pred__6781 = cljs.core.keyword_identical_QMARK_;
var expr__6782 = k__4180__auto__;
if(cljs.core.truth_(pred__6781.call(null,new cljs.core.Keyword(null,"cache-item","cache-item",-1193647857),expr__6782))){
return (new browse_scaler_cljc.s3.S3Client(G__6775,self__.get_item,self__.exists_QMARK_,self__.list_buckets,self__.__meta,self__.__extmap,null));
} else {
if(cljs.core.truth_(pred__6781.call(null,new cljs.core.Keyword(null,"get-item","get-item",-445412473),expr__6782))){
return (new browse_scaler_cljc.s3.S3Client(self__.cache_item,G__6775,self__.exists_QMARK_,self__.list_buckets,self__.__meta,self__.__extmap,null));
} else {
if(cljs.core.truth_(pred__6781.call(null,new cljs.core.Keyword(null,"exists?","exists?",1414473716),expr__6782))){
return (new browse_scaler_cljc.s3.S3Client(self__.cache_item,self__.get_item,G__6775,self__.list_buckets,self__.__meta,self__.__extmap,null));
} else {
if(cljs.core.truth_(pred__6781.call(null,new cljs.core.Keyword(null,"list-buckets","list-buckets",265873227),expr__6782))){
return (new browse_scaler_cljc.s3.S3Client(self__.cache_item,self__.get_item,self__.exists_QMARK_,G__6775,self__.__meta,self__.__extmap,null));
} else {
return (new browse_scaler_cljc.s3.S3Client(self__.cache_item,self__.get_item,self__.exists_QMARK_,self__.list_buckets,self__.__meta,cljs.core.assoc.call(null,self__.__extmap,k__4180__auto__,G__6775),null));
}
}
}
}
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (this__4184__auto__){
var self__ = this;
var this__4184__auto____$1 = this;
return cljs.core.seq.call(null,cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [(new cljs.core.MapEntry(new cljs.core.Keyword(null,"cache-item","cache-item",-1193647857),self__.cache_item,null)),(new cljs.core.MapEntry(new cljs.core.Keyword(null,"get-item","get-item",-445412473),self__.get_item,null)),(new cljs.core.MapEntry(new cljs.core.Keyword(null,"exists?","exists?",1414473716),self__.exists_QMARK_,null)),(new cljs.core.MapEntry(new cljs.core.Keyword(null,"list-buckets","list-buckets",265873227),self__.list_buckets,null))], null),self__.__extmap));
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (this__4171__auto__,G__6775){
var self__ = this;
var this__4171__auto____$1 = this;
return (new browse_scaler_cljc.s3.S3Client(self__.cache_item,self__.get_item,self__.exists_QMARK_,self__.list_buckets,G__6775,self__.__extmap,self__.__hash));
});

browse_scaler_cljc.s3.S3Client.prototype.cljs$core$ICollection$_conj$arity$2 = (function (this__4177__auto__,entry__4178__auto__){
var self__ = this;
var this__4177__auto____$1 = this;
if(cljs.core.vector_QMARK_.call(null,entry__4178__auto__)){
return this__4177__auto____$1.cljs$core$IAssociative$_assoc$arity$3(null,cljs.core._nth.call(null,entry__4178__auto__,(0)),cljs.core._nth.call(null,entry__4178__auto__,(1)));
} else {
return cljs.core.reduce.call(null,cljs.core._conj,this__4177__auto____$1,entry__4178__auto__);
}
});

browse_scaler_cljc.s3.S3Client.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"cache-item","cache-item",446883670,null),new cljs.core.Symbol(null,"get-item","get-item",1195119054,null),new cljs.core.Symbol(null,"exists?","exists?",-1239962053,null),new cljs.core.Symbol(null,"list-buckets","list-buckets",1906404754,null)], null);
});

browse_scaler_cljc.s3.S3Client.cljs$lang$type = true;

browse_scaler_cljc.s3.S3Client.cljs$lang$ctorPrSeq = (function (this__4208__auto__){
return (new cljs.core.List(null,"browse-scaler-cljc.s3/S3Client",null,(1),null));
});

browse_scaler_cljc.s3.S3Client.cljs$lang$ctorPrWriter = (function (this__4208__auto__,writer__4209__auto__){
return cljs.core._write.call(null,writer__4209__auto__,"browse-scaler-cljc.s3/S3Client");
});

/**
 * Positional factory function for browse-scaler-cljc.s3/S3Client.
 */
browse_scaler_cljc.s3.__GT_S3Client = (function browse_scaler_cljc$s3$__GT_S3Client(cache_item,get_item,exists_QMARK_,list_buckets){
return (new browse_scaler_cljc.s3.S3Client(cache_item,get_item,exists_QMARK_,list_buckets,null,null,null));
});

/**
 * Factory function for browse-scaler-cljc.s3/S3Client, taking a map of keywords to field values.
 */
browse_scaler_cljc.s3.map__GT_S3Client = (function browse_scaler_cljc$s3$map__GT_S3Client(G__6779){
return (new browse_scaler_cljc.s3.S3Client(new cljs.core.Keyword(null,"cache-item","cache-item",-1193647857).cljs$core$IFn$_invoke$arity$1(G__6779),new cljs.core.Keyword(null,"get-item","get-item",-445412473).cljs$core$IFn$_invoke$arity$1(G__6779),new cljs.core.Keyword(null,"exists?","exists?",1414473716).cljs$core$IFn$_invoke$arity$1(G__6779),new cljs.core.Keyword(null,"list-buckets","list-buckets",265873227).cljs$core$IFn$_invoke$arity$1(G__6779),null,cljs.core.not_empty.call(null,cljs.core.dissoc.call(null,G__6779,new cljs.core.Keyword(null,"cache-item","cache-item",-1193647857),new cljs.core.Keyword(null,"get-item","get-item",-445412473),new cljs.core.Keyword(null,"exists?","exists?",1414473716),new cljs.core.Keyword(null,"list-buckets","list-buckets",265873227))),null));
});

browse_scaler_cljc.s3.s3_operations = new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"cache-item","cache-item",-1193647857),browse_scaler_cljc.s3.cache_in_s3,new cljs.core.Keyword(null,"get-item","get-item",-445412473),browse_scaler_cljc.s3.get_from_s3,new cljs.core.Keyword(null,"exists?","exists?",1414473716),browse_scaler_cljc.s3.exists_in_s3_QMARK_,new cljs.core.Keyword(null,"list-buckets","list-buckets",265873227),browse_scaler_cljc.s3.list_buckets], null);

//# sourceMappingURL=s3.js.map
